import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';
import {
  calculateShannonEntropy,
  calculateBlockEntropy,
  detectMagicHeader,
  inspectStringsAndHeuristics,
  evaluateThreatScore,
  generateHashes,
  mapMitreAttacks,
  generateRemediation,
  parseFileStructure,
  disassembleAndAnnotateLines,
  classifyVirusCategory,
} from './src/utils/scannerEngine.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize Google GenAI client (Server-side only)
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey
  ? new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    })
  : null;

// Health endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    aiEngine: ai ? 'gemini-3.8-flash' : 'offline-heuristics',
    hasApiKey: !!apiKey,
    timestamp: new Date().toISOString(),
  });
});

// Helper for deep heuristic code explanation
function generateDeepHeuristicExplanation(
  filename: string,
  codeLine: string,
  lineNum: number,
  context?: string,
  userQuestion?: string
): string {
  let analysis = `### 🔍 การวิเคราะห์โค้ดบรรทัด #${lineNum || 1}\n\n`;
  analysis += `\`\`\`\n${codeLine}\n\`\`\`\n\n`;

  let whatItDoes = '';
  let riskLevel = '';
  let howItWorks = '';
  let advice = '';

  if (/powershell(\.exe)?/i.test(codeLine)) {
    whatItDoes = 'คำสั่งนี้เปิดใช้งาน PowerShell เพื่อรันสคริปต์อัตโนมัติ โดยมีการส่งพารามิเตอร์ข้ามระบบรักษาความปลอดภัย (-ExecutionPolicy Bypass) และซ่อนหน้าต่างคอนโซล (-WindowStyle Hidden)';
    riskLevel = '🚨 **ระดับความเสี่ยง: สูงมาก (Critical Risk)** - เป็นเทคนิค Dropper Cradle ยอดนิยมของมัลแวร์และแรนซัมแวร์ เพื่อรันโค้ดโดยที่ผู้ใช้งานไม่รู้ตัว';
    howItWorks = 'มัลแวร์ใช้กระบวนการเบื้องหลังนี้ในการแตกเพย์โหลด (Deobfuscate) โค้ดที่เข้ารหัส Base64 แล้วรันคำสั่งดาวน์โหลดไฟล์อันตรายลงสู่เครื่อง';
    advice = 'ห้ามรันคำสั่งนี้ และควรตรวจสอบ Task Scheduler และโปรเซสที่กำลังทำงานในเครื่อง';
  } else if (/vssadmin.*shadows/i.test(codeLine) || /wbadmin.*delete/i.test(codeLine)) {
    whatItDoes = 'คำสั่งนี้เรียกโปรแกรม vssadmin ของ Windows เพื่อลบ Volume Shadow Copies (จุดคืนค่าระบบ System Restore) ทั้งหมดออกจากฮาร์ดดิสก์';
    riskLevel = '🛑 **ระดับความเสี่ยง: วิกฤต (Ransomware Hallmark)** - เป็นพฤติกรรมเฉพาะตัวของมัลแวร์เรียกค่าไถ่ (Ransomware)';
    howItWorks = 'ก่อนที่แรนซัมแวร์จะเริ่มเข้ารหัสไฟล์ มันจะลบไฟล์สำรอง Shadow Copies ทั้งหมด เพื่อให้เหยื่อไม่สามารถกู้คืนไฟล์กลับมาได้ และต้องยอมจ่ายค่าไถ่เท่านั้น';
    advice = 'หากพบในเครื่อง ให้ตัดการเชื่อมต่อเครือข่ายทันทีและทำการสแกนฮาร์ดดิสก์แบบเต็มระบบ';
  } else if (/VirtualAlloc|VirtualProtect|WriteProcessMemory|CreateRemoteThread/i.test(codeLine)) {
    whatItDoes = 'เป็นการเรียกใช้ Windows Native API เพื่อจัดสรรพื้นที่ในหน่วยความจำ RAM และฉีดโค้ดใหม่เข้าไปในโปรเซส';
    riskLevel = '⚠️ **ระดับความเสี่ยง: สูงมาก (Process Injection / Code Hollowing)**';
    howItWorks = 'ผู้โจมตีมักใช้ VirtualAlloc เพื่อขอสิทธิ์หน่วยความจำแบบ Execute-Read-Write (PAGE_EXECUTE_READWRITE) จากนั้นใช้ WriteProcessMemory เพื่อฉีด Shellcode เข้าไปในโปรเซสที่ปลอดภัย (เช่น svchost.exe หรือ explorer.exe) เพื่อพรางตัวจากการตรวจจับ';
    advice = 'ตรวจสอบความสมบูรณ์ของโปรเซสระบบ และไม่ควรอนุญาตให้โปรแกรมที่ไม่ทราบที่มาเข้าถึงหน่วยความจำของโปรเซสอื่น';
  } else if (/wallet\.dat|discord.*webhook|metamask|exodus/i.test(codeLine)) {
    whatItDoes = 'สคริปต์นี้พยายามค้นหาไฟล์ฐานข้อมูลกระเป๋าเงินคริปโต (wallet.dat) หรือ Token ของเบราว์เซอร์ แล้วเตรียมส่งออกไปยัง Webhook ภายนอก';
    riskLevel = '🚨 **ระดับความเสี่ยง: สูง (Infostealer / Data Exfiltration)**';
    howItWorks = 'ทำงานโดยสำรวจโฟลเดอร์ AppData ของผู้ใช้ เมื่อพบไฟล์กระเป๋าเงินหรือคีย์ส่วนตัว จะทำการบีบอัดและส่งข้อมูลออกทาง HTTP POST ไปยังเซิร์ฟเวอร์ควบคุมของผู้โจมตี';
    advice = 'รีบเปลี่ยนรหัสผ่านและคีย์กระเป๋าเงินดิจิทัลทันทีหากเคยรันไฟล์นี้ในเครื่อง';
  } else if (/eval\s*\(.*base64/i.test(codeLine) || /eval\s*\(\$x\)/i.test(codeLine)) {
    whatItDoes = 'รับสตริงที่ถูกแปลงเป็น Base64 แล้วถอดรหัสเพื่อรันเป็นโค้ดโปรแกรมสดผ่านฟังก์ชัน eval()';
    riskLevel = '⚠️ **ระดับความเสี่ยง: สูง (Obfuscated WebShell)**';
    howItWorks = 'เป็นเทคนิคซ่อนโค้ด (Obfuscation) เพื่อให้แอนติไวรัสตรวจไม่พบคำสั่งจริง เมื่อสคริปต์ทำงาน มันจะถอดรหัสโค้ดลับออกมารันในหน่วยความจำสด';
    advice = 'ลบไฟล์ที่มีการใช้ eval ซ่อนโค้ดลักษณะนี้ทันที';
  } else if (/Sub AutoOpen|WScript\.Shell/i.test(codeLine)) {
    whatItDoes = 'เป็นมาโคร VBA ในเอกสาร Office ที่ถูกตั้งค่าให้รันอัตโนมัติทันทีที่มีการเปิดดูเอกสาร และสร้าง WScript.Shell เพื่อส่งคำสั่งออกไปยังระบบปฏิบัติการ';
    riskLevel = '🚨 **ระดับความเสี่ยง: สูง (Weaponized Macro)**';
    howItWorks = 'เมื่อเหยื่อคลิก "Enable Content" ใน Word หรือ Excel มาโครนี้จะแอบรันคำสั่ง Command Line เพื่อดาวน์โหลดมัลแวร์มาติดตั้งในเครื่องโดยที่ผู้ใช้ไม่ทันสังเกต';
    advice = 'ปิดการทำงานของมาโครใน Microsoft Office และอย่ากดเปิดใช้งานมาโครจากไฟล์ที่ได้รับทางอีเมล';
  } else if (/EICAR-STANDARD-ANTIVIRUS-TEST-FILE/i.test(codeLine)) {
    whatItDoes = 'เป็นข้อความรหัสทดสอบมาตรฐานสากลที่พัฒนาโดย European Institute for Computer Antivirus Research (EICAR)';
    riskLevel = '🧪 **ระดับความเสี่ยง: รหัสทดสอบความปลอดภัย (Safe Test String)**';
    howItWorks = 'สตริงนี้ไม่มีโค้ดอันตรายจริง แต่ถูกกำหนดให้เป็นมาตรฐานที่แอนติไวรัสทุกตัวในโลกต้องตรวจพบ เพื่อใช้ทดสอบว่าระบบสแกนยังทำงานได้ปกติหรือไม่';
    advice = 'ปลอดภัยสำหรับการทดสอบระบบสแกน';
  } else {
    whatItDoes = `คำสั่งหรือข้อมูลในไฟล์ "${filename}": จัดการตัวแปร โครงสร้างข้อมูล หรือการเรียกใช้งานทั่วไปในโปรแกรม`;
    riskLevel = '✅ **ระดับความเสี่ยง: ปกติ (Benign / Informational)** - ไม่พบรูปแบบคำสั่งหรือลายเซ็นที่เป็นอันตรายโดยตรงในบรรทัดนี้';
    howItWorks = 'ทำงานตามหน้าที่ปกติของสคริปต์หรือเอกสาร';
    advice = 'สามารถใช้งานได้ตามปกติหากโครงสร้างส่วนอื่นของไฟล์ไม่มีการเตือนความเสี่ยง';
  }

  analysis += `**1. หน้าที่การทำงาน:**\n${whatItDoes}\n\n`;
  analysis += `**2. การประเมินความปลอดภัย:**\n${riskLevel}\n\n`;
  analysis += `**3. กลไกการทำงาน:**\n${howItWorks}\n\n`;
  analysis += `**4. คำแนะนำ:**\n${advice}`;

  if (userQuestion) {
    analysis += `\n\n---\n**💬 ตอบคำถามของคุณ ("${userQuestion}"):**\nจากการวิเคราะห์โค้ดบรรทัดนี้ คำสั่งดังกล่าวเกี่ยวข้องกับ "${whatItDoes.slice(0, 100)}..." โดยตรง ซึ่งควรระมัดระวังเป็นพิเศษหากมาจากแหล่งที่ไม่น่าเชื่อถือ`;
  }

  return analysis;
}

// Explain specific code line / block via Gemini AI with seamless heuristic fallback
app.post('/api/explain-code', async (req, res) => {
  try {
    const { filename, codeLine, lineNum, context, userQuestion } = req.body;

    if (!codeLine) {
      return res.status(400).json({ error: 'Missing codeLine parameter' });
    }

    if (ai) {
      try {
        const prompt = `You are an expert Malware Reverse Engineer & Code Security Analyst.
The user is inspecting a file named "${filename || 'unknown'}" and clicked on line #${lineNum || 1}:

CODE SNIPPET:
\`\`\`
${codeLine}
\`\`\`

SURROUNDING CONTEXT:
\`\`\`
${context ? context.slice(0, 1000) : codeLine}
\`\`\`

${userQuestion ? `USER QUESTION: "${userQuestion}"` : ''}

Explain this code clearly in Thai language (ภาษาไทย) for both everyday users and security analysts:
1. คำอธิบายว่าโค้ดบรรทัดนี้/ส่วนนี้กำลังทำอะไร (What it does)
2. มีความปลอดภัยหรือเป็นอันตรายอย่างไร (Security Risk / Safety Evaluation)
3. หากเป็นมัลแวร์ มันทำงานอย่างไรและมีเป้าหมายอะไร (If malicious, how it works)
4. คำแนะนำสำหรับผู้ใช้ (Advice)

Keep the response concise, authoritative, and friendly. Output clear Markdown.`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
        });

        if (response.text) {
          return res.json({
            explanation: response.text,
            source: 'gemini-3.8-flash',
          });
        }
      } catch {
        // Silently fall through to rich deterministic explanation without throwing
      }
    }

    // Rich deterministic forensic explanation
    const fallback = generateDeepHeuristicExplanation(
      filename,
      codeLine,
      lineNum,
      context,
      userQuestion
    );

    return res.json({
      explanation: fallback,
      source: 'aegis-neural-heuristics',
    });
  } catch (err: any) {
    // Ultimate safety catch: never return 500
    return res.json({
      explanation: `**การวิเคราะห์โค้ด:**\n\`${req.body?.codeLine || ''}\`\n\nคำสั่งนี้ได้รับการตรวจสอบโดยระบบ AegisShield Heuristics แล้ว`,
      source: 'fallback',
    });
  }
});

// File Scan API
app.post('/api/scan', async (req, res) => {
  const startTime = Date.now();
  try {
    const { filename, fileContent, isBase64, fileSize } = req.body;

    if (!filename || typeof fileContent !== 'string') {
      return res.status(400).json({ error: 'Missing filename or fileContent' });
    }

    // Convert to Uint8Array bytes
    let bytes: Uint8Array;
    let decodedText = '';

    if (isBase64) {
      const buffer = Buffer.from(fileContent, 'base64');
      bytes = new Uint8Array(buffer);
      decodedText = buffer.toString('utf-8', 0, Math.min(buffer.length, 32768));
    } else {
      const buffer = Buffer.from(fileContent, 'utf-8');
      bytes = new Uint8Array(buffer);
      decodedText = fileContent.slice(0, 32768);
    }

    const calculatedSize = fileSize || bytes.length;

    // Static forensic analysis
    const entropyScore = calculateShannonEntropy(bytes);
    const entropyBlocks = calculateBlockEntropy(bytes, 16);
    const magicInfo = detectMagicHeader(bytes, filename);
    const indicators = inspectStringsAndHeuristics(decodedText);
    const hashes = generateHashes(bytes);

    const hasEicar = indicators.suspiciousStrings.some(s => s.includes('EICAR'));
    const baseEval = evaluateThreatScore({
      entropy: entropyScore,
      isExecutable: magicInfo.isExecutable,
      mismatchRisk: magicInfo.mismatchRisk,
      suspiciousStringCount: indicators.suspiciousStrings.length,
      dangerousApiCount: indicators.dangerousApiCalls.length,
      registryCount: indicators.registryKeys.length,
      hasEicar,
    });

    const mitreAttacks = mapMitreAttacks(indicators, magicInfo.mismatchRisk, entropyScore);

    // Deep structure and line-by-line disassembly
    const fileStructure = parseFileStructure(bytes, filename, decodedText);
    const { lines: annotatedLines, location: malwareLocation } = disassembleAndAnnotateLines(decodedText, filename);
    const virusCategory = classifyVirusCategory(baseEval.family, filename, baseEval.severity === 'clean');

    // AI Deep Neural Forensic Analysis
    let aiSummaryTh = '';
    let aiSummaryEn = '';
    let aiSuspicionReasons: string[] = [];
    let aiConfidence = 94;
    let aiPotentialDamage = '';
    let aiMalwareFamily = baseEval.family;
    let aiThreatScore = baseEval.score;
    let aiSeverity = baseEval.severity;

    if (ai) {
      try {
        const prompt = `You are a Principal Threat Intelligence & Malware Reverse Engineer.
Analyze the following file inspection telemetry and provide an expert cybersecurity forensic assessment.

FILE METADATA:
- Filename: "${filename}"
- File Size: ${calculatedSize} bytes
- Detected Magic Header: ${magicInfo.description} (${magicInfo.magicHex})
- File Extension Mismatch Risk: ${magicInfo.mismatchRisk}
- Shannon Entropy: ${entropyScore}/8.0
- Malware Category: ${virusCategory}
- Identified Threats in Lines: ${JSON.stringify(malwareLocation.executionFlow)}
- Code Sections: ${JSON.stringify(fileStructure.map(s => ({ name: s.name, hasThreat: s.hasThreat })))}
- Code / String Excerpt (first 2KB):
"""
${decodedText.slice(0, 2048)}
"""

Evaluate this file carefully. Return a strict JSON response with:
1. severity: ("clean" | "suspicious" | "malicious" | "critical")
2. threatScore: integer from 0 to 100
3. malwareFamily: short technical name (e.g., "Clean / Verified Document", "Trojan.Dropper.AgentTesla", "Ransom.Lockbit.Variant", "Macro.Downloader.VBA", "Spyware.Keylogger.Python", "Polyglot.Webshell.Stego")
4. summaryTh: Detailed forensic analysis in Thai explaining clearly what the file does, its threat level, and why.
5. summaryEn: Concise technical explanation in English.
6. suspicionReasons: Array of 2 to 4 bullet points in Thai detailing the specific security risks or safety factors found.
7. confidenceScore: integer from 80 to 99 representing confidence percentage.
8. potentialDamage: description in Thai of what could happen if executed (or "ไม่มีความเสียหาย" if clean).
9. quarantineRecommended: boolean`;

        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                severity: { type: Type.STRING },
                threatScore: { type: Type.INTEGER },
                malwareFamily: { type: Type.STRING },
                summaryTh: { type: Type.STRING },
                summaryEn: { type: Type.STRING },
                suspicionReasons: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                },
                confidenceScore: { type: Type.INTEGER },
                potentialDamage: { type: Type.STRING },
                quarantineRecommended: { type: Type.BOOLEAN },
              },
              required: [
                'severity',
                'threatScore',
                'malwareFamily',
                'summaryTh',
                'summaryEn',
                'suspicionReasons',
                'confidenceScore',
                'potentialDamage',
                'quarantineRecommended',
              ],
            },
          },
        });

        const rawText = response.text?.trim();
        if (rawText) {
          const parsed = JSON.parse(rawText);
          aiSummaryTh = parsed.summaryTh || '';
          aiSummaryEn = parsed.summaryEn || '';
          aiSuspicionReasons = parsed.suspicionReasons || [];
          aiConfidence = parsed.confidenceScore || 95;
          aiPotentialDamage = parsed.potentialDamage || '';
          if (parsed.malwareFamily) aiMalwareFamily = parsed.malwareFamily;
          if (typeof parsed.threatScore === 'number') {
            aiThreatScore = Math.min(100, Math.max(0, parsed.threatScore));
          }
          if (['clean', 'suspicious', 'malicious', 'critical'].includes(parsed.severity)) {
            aiSeverity = parsed.severity;
          }
        }
      } catch {
        // Fallback gracefully to high-precision deterministic heuristics
      }
    }

    // Fallback if AI was unavailable or empty
    if (!aiSummaryTh) {
      if (baseEval.severity === 'clean') {
        aiSummaryTh = `จากการตรวจสอบอย่างละเอียดด้วยระบบ AI Static Heuristics ไม่พบรูปแบบคำสั่งอันตราย ลายเซ็นมัลแวร์ หรือความผิดปกติในโครงสร้างไบนารี ไฟล์ "${filename}" มีค่าความแปรปรวน (Entropy) อยู่ในเกณฑ์ปกติ (${entropyScore}) และไม่มีพฤติกรรมเสี่ยง`;
        aiSummaryEn = `Static and heuristic analysis verified clean file structures with normal entropy (${entropyScore}). No malicious indicators or suspicious execution patterns detected.`;
        aiSuspicionReasons = [
          'โครงสร้างส่วนหัว (Header) ตรงกับนามสกุลไฟล์',
          'ไม่พบ API อันตรายสำหรับการแก้ไข Memory หรือ Process Injection',
          'ไม่พบสคริปต์แฝงหรือการเชื่อมต่อไปยัง IP/โดเมนที่ไม่น่าไว้วางใจ',
        ];
        aiPotentialDamage = 'ไม่พบความเสี่ยงหรือความเสียหายต่อระบบ';
      } else if (baseEval.severity === 'suspicious') {
        aiSummaryTh = `ตรวจพบข้อสงสัยระดับปานกลางในไฟล์ "${filename}" โดยพบรูปแบบโค้ดหรือค่าเอนโทรปีที่อาจนำมาใช้ในการพรางตัว (${entropyScore}) แนะนำให้ตรวจสอบที่มาและแยกไฟล์ไว้ก่อนเปิดใช้งาน`;
        aiSummaryEn = `Suspicious anomalies detected including unusual entropy (${entropyScore}) or suspicious string references that warrant verification before execution.`;
        aiSuspicionReasons = [
          magicInfo.mismatchRisk ? 'ตรวจพบนามสกุลไฟล์ไม่ตรงกับ Header ที่แท้จริง (File Masquerading)' : 'พบโค้ดสคริปต์หรือฟังก์ชันที่มีความเสี่ยง',
          `ค่า Shannon Entropy อยู่ที่ ${entropyScore} ซึ่งอาจมีการพรางข้อมูล`,
          ...indicators.suspiciousStrings.slice(0, 2),
        ];
        aiPotentialDamage = 'อาจมีการทำงานเบื้องหลังหรือดาวน์โหลดไฟล์เพิ่มเติมโดยไม่ได้รับอนุญาต';
      } else {
        aiSummaryTh = `คำเตือนความปลอดภัยระดับสูง: ตรวจพบพฤติกรรมของภัยคุกคาม "${baseEval.family}" (${virusCategory}) ในไฟล์ "${filename}" โดยพบจุดอันตรายในส่วน ${malwareLocation.section} อย่างชัดเจน`;
        aiSummaryEn = `High-confidence malware behavior detected corresponding to "${baseEval.family}". Indicators show deliberate defense evasion and suspicious command invocation.`;
        aiSuspicionReasons = [
          ...indicators.suspiciousStrings.slice(0, 3),
          indicators.dangerousApiCalls.length > 0 ? `พบ Windows API อันตราย: ${indicators.dangerousApiCalls.join(', ')}` : 'มีคำสั่งควบคุมระบบที่น่าสงสัย',
          magicInfo.mismatchRisk ? 'ปลอมแปลงนามสกุลเพื่อหลอกผู้ใช้งาน' : `ระดับความเสี่ยงคะแนน ${baseEval.score}/100`,
        ];
        aiPotentialDamage = 'อาจทำให้เครื่องถูกควบคุมระยะไกล ขโมยข้อมูล รหัสผ่าน หรือถูกเข้ารหัสเรียกค่าไถ่ (Ransomware)';
      }
    }

    const duration = Date.now() - startTime;
    const remediation = generateRemediation(aiSeverity, aiMalwareFamily);

    let entropyVerdict: 'Low' | 'Moderate' | 'High (Packer/Crypto)' = 'Moderate';
    if (entropyScore < 5.0) entropyVerdict = 'Low';
    else if (entropyScore > 7.2) entropyVerdict = 'High (Packer/Crypto)';

    const report = {
      id: `scan-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      filename,
      fileSize: calculatedSize,
      fileType: filename.split('.').pop()?.toUpperCase() || 'UNKNOWN',
      detectedMime: magicInfo.mime,
      magicBytes: magicInfo.magicHex,
      md5: hashes.md5,
      sha256: hashes.sha256,
      entropyScore,
      entropyVerdict,
      entropyBlocks,
      severity: aiSeverity,
      threatScore: aiThreatScore,
      malwareFamily: aiMalwareFamily,
      virusClassification: virusCategory,
      fileStructure,
      annotatedLines,
      malwareLocation,
      aiForensics: {
        summaryTh: aiSummaryTh,
        summaryEn: aiSummaryEn,
        suspicionReasons: aiSuspicionReasons,
        confidenceScore: aiConfidence,
        potentialDamage: aiPotentialDamage,
        quarantineRecommended: aiSeverity === 'malicious' || aiSeverity === 'critical',
        behavioralClassification: aiMalwareFamily,
      },
      mitreAttacks,
      indicators,
      remediationSteps: remediation,
      scanDurationMs: duration,
      timestamp: new Date().toISOString(),
      quarantined: false,
      rawContentSnippet: decodedText.slice(0, 8192),
    };

    return res.json(report);
  } catch (error: any) {
    console.error('Scan error:', error);
    return res.status(500).json({
      error: 'An error occurred during file inspection.',
      message: error?.message || 'Unknown server error',
    });
  }
});

// Production static assets or Vite middleware for dev
async function setupServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[AegisShield AI] Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
