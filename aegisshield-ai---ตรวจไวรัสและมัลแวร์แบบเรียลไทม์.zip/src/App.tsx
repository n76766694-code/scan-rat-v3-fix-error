/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DashboardStats } from './components/DashboardStats';
import { FileUploader } from './components/FileUploader';
import { ScanningOverlay } from './components/ScanningOverlay';
import { ScanResultModal } from './components/ScanResultModal';
import { ScanHistoryTable } from './components/ScanHistoryTable';
import { ThreatRadarWidget } from './components/ThreatRadarWidget';
import { ScanReport } from './types/scanner';
import {
  calculateShannonEntropy,
  calculateBlockEntropy,
  detectMagicHeader,
  inspectStringsAndHeuristics,
  evaluateThreatScore,
  generateHashes,
  mapMitreAttacks,
  generateRemediation,
  parseFileStructure,
  disassembleAndAnnotateLines,
  classifyVirusCategory,
} from './utils/scannerEngine';

const INITIAL_REPORTS: ScanReport[] = [
  {
    id: 'scan-init-001',
    filename: 'Invoice_Payment_INV8842.pdf',
    fileSize: 48250,
    fileType: 'PDF',
    detectedMime: 'application/pdf',
    magicBytes: '25 50 44 46 2D 31 2E 37',
    md5: '8f7a93b4e1c2d3e4f5a6b7c8d9e0f1a2',
    sha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    entropyScore: 4.82,
    entropyVerdict: 'Low',
    entropyBlocks: [4.2, 4.5, 4.8, 5.0, 4.9, 4.6, 4.7, 4.8, 4.9, 5.1, 4.7, 4.6, 4.8, 4.9, 4.7, 4.5],
    severity: 'clean',
    threatScore: 0,
    malwareFamily: 'Clean / Verified Adobe PDF Document',
    virusClassification: 'Clean',
    fileStructure: [
      {
        name: '%PDF-1.7 Header',
        size: 32,
        entropy: 2.9,
        description: 'ลายเซ็นมาตรฐานของเอกสาร PDF',
        hasThreat: false,
        offsetHex: '0x0000 - 0x0020',
      },
      {
        name: 'Catalog & Pages Tree (Obj 1, 2)',
        size: 16800,
        entropy: 4.4,
        description: 'โครงสร้างลำดับหน้ากระดาษและแคตตาล็อกสารบัญ',
        hasThreat: false,
        offsetHex: 'Obj 1 - Obj 2',
      },
      {
        name: 'Content Stream & Text Render (Obj 3, 4)',
        size: 21600,
        entropy: 4.9,
        description: 'ข้อมูลสตรีมข้อความ รูปภาพ และแบบอักษรสำหรับแสดงผล',
        hasThreat: false,
        offsetHex: 'Stream 4 0 R',
      },
      {
        name: 'Xref Table & Trailer',
        size: 8600,
        entropy: 3.8,
        description: 'ตาราง Cross-reference อ้างอิงตำแหน่งอ็อบเจกต์ในไฟล์',
        hasThreat: false,
        offsetHex: 'Trailer / EOF',
      },
    ],
    annotatedLines: [
      { lineNum: 1, content: '%PDF-1.7', isMalicious: false, explanation: 'ส่วนหัวระบุเวอร์ชันของรูปแบบไฟล์ PDF 1.7 มาตรฐาน' },
      { lineNum: 2, content: '1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj', isMalicious: false, explanation: 'อ็อบเจกต์สารบัญหลักของเอกสาร PDF' },
      { lineNum: 3, content: '2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj', isMalicious: false, explanation: 'ตารางระบุจำนวนหน้ากระดาษ (1 หน้า)' },
      { lineNum: 4, content: '3 0 obj << /Type /Page /Parent 2 0 R /Contents 4 0 R >> endobj', isMalicious: false, explanation: 'ข้อมูลเรนเดอร์หน้ากระดาษ ไม่พบการเรียก /JavaScript หรือ /Launch' },
      { lineNum: 5, content: '(TAX INVOICE - ACME CORP - TOTAL: $1,450.00 USD - STATUS: PAID) Tj', isMalicious: false, explanation: 'ข้อความใบแจ้งหนี้ปกติสำหรับการแสดงผล' },
    ],
    malwareLocation: {
      section: 'ทุกส่วนโครงสร้างปลอดภัย (Clean Structure)',
      lineNumbers: [],
      offsetHex: '0x0000',
      executionFlow: ['ไม่พบคำสั่งอันตราย ลำดับการทำงานปลอดภัยตามปกติ'],
      payloadAnalysis: 'ตรวจสอบโครงสร้างและโค้ดทั้งหมดแล้ว ไม่พบการทำงานที่ผิดปกติ',
      howItWorksTh: 'ไฟล์นี้ไม่มีกลไกการโจมตีหรือการแอบแฝงโค้ดอันตราย ปลอดภัยต่อการใช้งาน',
    },
    aiForensics: {
      summaryTh: 'ไฟล์เอกสาร PDF สำหรับใบแจ้งหนี้ผ่านการตรวจวิเคราะห์อย่างสมบูรณ์ ไม่พบการแทรกคำสั่ง /JavaScript หรือ /OpenAction โครงสร้างไฟล์ถูกต้องตามมาตรฐาน PDF 1.7 และไม่มีการเชื่อมต่อเครือข่ายแฝง',
      summaryEn: 'Legitimate PDF invoice document. Zero embedded JavaScript objects or launch actions detected. Complies with ISO 32000 specification.',
      suspicionReasons: [
        'ส่วนหัว (Header) เป็นไปตามมาตรฐาน Adobe PDF 1.7',
        'ไม่พบออบเจกต์สคริปต์ /Launch หรือ /JavaScript',
        'ค่า Shannon Entropy อยู่ในเกณฑ์ 4.82 ปกติสำหรับเอกสารข้อความ',
      ],
      confidenceScore: 98,
      potentialDamage: 'ไม่มีความเสียหาย ไฟล์มีความปลอดภัยสูง',
      quarantineRecommended: false,
      behavioralClassification: 'Clean / Verified Document',
    },
    mitreAttacks: [],
    indicators: {
      suspiciousStrings: [],
      urlsOrIps: [],
      registryKeys: [],
      dangerousApiCalls: [],
      networkActivityRisk: 'None',
    },
    remediationSteps: [
      'ไฟล์นี้ปลอดภัยสำหรับการเปิดและแชร์ภายในองค์กร',
      'ไม่มีความจำเป็นต้องดำเนินการใดๆ เพิ่มเติม',
    ],
    scanDurationMs: 245,
    timestamp: new Date(Date.now() - 1000 * 60 * 14).toISOString(),
    quarantined: false,
  },
  {
    id: 'scan-init-002',
    filename: 'Windows11_Security_Patch_KB502.exe',
    fileSize: 124500,
    fileType: 'EXE',
    detectedMime: 'application/x-dosexec',
    magicBytes: '4D 5A 90 00 03 00 00 00',
    md5: '7d6e5c4b3a2f1e0d9c8b7a6f5e4d3c2b',
    sha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
    entropyScore: 7.84,
    entropyVerdict: 'High (Packer/Crypto)',
    entropyBlocks: [5.2, 5.8, 7.8, 7.9, 7.9, 7.9, 7.8, 7.9, 7.9, 7.9, 7.8, 7.9, 7.9, 7.8, 7.9, 6.4],
    severity: 'critical',
    threatScore: 96,
    malwareFamily: 'Trojan.Dropper.PackedRansom',
    virusClassification: 'Trojan',
    fileStructure: [
      {
        name: 'DOS Header & Stub',
        size: 256,
        entropy: 3.12,
        description: 'ส่วนหัวเริ่มต้นสำหรับความเข้ากันได้ย้อนหลัง (MZ Signature 0x5A4D)',
        hasThreat: false,
        offsetHex: '0x0000 - 0x00FF',
      },
      {
        name: 'PE Header & Optional Header',
        size: 1024,
        entropy: 4.25,
        description: 'ข้อมูลสถาปัตยกรรม (x86/x64), ImageBase, และ Entry Point สำหรับ CPU',
        hasThreat: false,
        offsetHex: '0x0100 - 0x027F',
      },
      {
        name: '.text (Executable Code)',
        size: 56000,
        entropy: 7.82,
        description: 'พื้นที่จัดเก็บ Machine Code คำสั่งการทำงานของโปรแกรม แฝงโค้ดบีบอัดและ PowerShell',
        hasThreat: true,
        offsetHex: '0x0280 - 0x2A00',
      },
      {
        name: '.rdata (Imports & Read-only)',
        size: 27000,
        entropy: 5.21,
        description: 'ตาราง Import Address Table (IAT) บันทึกการเรียก VirtualAlloc, WriteProcessMemory',
        hasThreat: true,
        offsetHex: '0x2A00 - 0x4200',
      },
      {
        name: '.data & .rsrc (Data & Resources)',
        size: 25000,
        entropy: 7.64,
        description: 'ตัวแปรส่วนกลาง แฝง Encrypted Payload Dropper',
        hasThreat: true,
        offsetHex: '0x4200 - EOF',
      },
    ],
    annotatedLines: [
      { lineNum: 1, content: 'MZ\\x90\\x00\\x03\\x00\\x00\\x00', isMalicious: false, explanation: 'Magic bytes PE Header' },
      { lineNum: 2, content: 'This program cannot be run in DOS mode.', isMalicious: false, explanation: 'ข้อความ DOS Stub มาตรฐาน' },
      { lineNum: 3, content: 'powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand aAB0AHQAcAA6...', isMalicious: true, threatTag: 'PowerShell Stealth Cradle', explanation: 'รันคำสั่ง PowerShell ซ่อนหน้าต่างเพื่อดึง Payload ระยะไกลมาทำงาน' },
      { lineNum: 4, content: 'vssadmin.exe delete shadows /all /quiet', isMalicious: true, threatTag: 'Ransomware Shadow Deletion', explanation: 'ลบ Shadow Copies ของ Windows เพื่อไม่ให้เหยื่อกู้คืนไฟล์ได้' },
      { lineNum: 5, content: 'VirtualAlloc(0, 4096, MEM_COMMIT, PAGE_EXECUTE_READWRITE)', isMalicious: true, threatTag: 'Process Injection (Memory Alloc)', explanation: 'จองพื้นที่หน่วยความจำแบบ Execute-Read-Write เพื่อเตรียมรัน Shellcode' },
      { lineNum: 6, content: 'WriteProcessMemory(hProcess, pRemote, buf, len, null)', isMalicious: true, threatTag: 'Code Hollowing Injection', explanation: 'เขียนโค้ดมัลแวร์ทับลงในโปรเซสระบบที่ถูกต้อง' },
      { lineNum: 7, content: 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run', isMalicious: true, threatTag: 'Registry Persistence', explanation: 'ติดตั้ง Autorun ใน Registry เพื่อทำงานอัตโนมัติทุกครั้งที่เปิดเครื่อง' },
    ],
    malwareLocation: {
      section: '.text / Code Segment (Offset 0x0280)',
      lineNumbers: [3, 4, 5, 6, 7],
      offsetHex: '0x0280',
      executionFlow: [
        'บรรทัดที่ 3: สปอว์นโปรเซส PowerShell ซ่อนหน้าต่างและหลบเลี่ยง Execution Policy',
        'บรรทัดที่ 4: ลบไฟล์สำรอง Shadow Copies ด้วยคำสั่ง vssadmin',
        'บรรทัดที่ 5: จัดสรรหน่วยความจำแบบ PAGE_EXECUTE_READWRITE ด้วย VirtualAlloc',
        'บรรทัดที่ 6: ฉีดโค้ดมัลแวร์เข้าสู่โปรเซสระบบผ่าน WriteProcessMemory',
        'บรรทัดที่ 7: เขียน Registry Run Key เพื่อคงอยู่ถาวร (Persistence)',
      ],
      payloadAnalysis: 'ตรวจพบโค้ดอันตรายใน 5 ตำแหน่งสำคัญ บ่งชี้การทำงานเป็นโทรจันปล่อยแรนซัมแวร์',
      howItWorksTh: 'มัลแวร์ในไฟล์นี้ทำงานโดยเริ่มต้นจากการเรียก PowerShell แบบซ่อนหน้าต่าง จากนั้นจะลบระบบสำรองข้อมูล Shadow Copies และใช้ VirtualAlloc เพื่อฉีดโค้ดเข้ารหัสไฟล์ลงในระบบ',
    },
    aiForensics: {
      summaryTh: 'ตรวจพบโทรจันระดับวิกฤตแฝงตัวเป็นตัวอัปเดตระบบปฏิบัติการ Windows! โครงสร้างไบนารีมีค่าเอนโทรปีสูงผิดปกติ (7.84) แสดงถึงการบีบอัดโค้ดเพย์โหลดเพื่อหลบเลี่ยงแอนติไวรัส มีคำสั่งลบ Volume Shadow Copies (vssadmin) และเปิดสคริปต์ PowerShell ในโหมดซ่อนตัว',
      summaryEn: 'Critical weaponized Trojan dropper masquerading as a Windows system patch. High entropy (7.84) reveals packed malicious payload with shadow copy deletion and hidden PowerShell invocation.',
      suspicionReasons: [
        'ตรวจพบคำสั่งลบข้อมูลสำรอง shadow copies ป้องกันการกู้ไฟล์',
        'พยายามเรียกใช้ PowerShell Bypass ในโหมด Hidden Window',
        'พบการเรียก Windows API: VirtualAlloc และ WriteProcessMemory สำหรับ Process Injection',
      ],
      confidenceScore: 99,
      potentialDamage: 'สามารถเข้ารหัสไฟล์เพื่อเรียกค่าไถ่ (Ransomware) ขโมยข้อมูลระบุตัวตน และเปิดช่องโหว่ควบคุมระยะไกล',
      quarantineRecommended: true,
      behavioralClassification: 'Trojan.Dropper.PackedRansom',
    },
    mitreAttacks: [
      {
        id: 'T1490',
        tactic: 'Impact',
        technique: 'Inhibit System Recovery: VSS Deletion',
        description: 'ลบสำเนาเงาของระบบเพื่อไม่ให้เหยื่อสามารถกู้คืนข้อมูลได้',
      },
      {
        id: 'T1059.001',
        tactic: 'Execution',
        technique: 'Command and Scripting Interpreter: PowerShell',
        description: 'เรียกคำสั่ง PowerShell แบบซ่อนหน้าต่างเพื่อดาวน์โหลด Secondary Payload',
      },
      {
        id: 'T1055',
        tactic: 'Defense Evasion',
        technique: 'Process Injection: VirtualAlloc / WriteProcessMemory',
        description: 'ฉีดโค้ดแปลกปลอมเข้าสู่โปรเซสระบบที่ถูกต้องเพื่อหลบเลี่ยงการตรวจสอบ',
      },
    ],
    indicators: {
      suspiciousStrings: [
        'PowerShell Hidden / Encoded Execution',
        'Ransomware Tactic: VSS Shadow Copy Deletion',
        'Living-off-the-Land (Certutil Download)',
      ],
      urlsOrIps: ['http://91.240.118.42:8080/stage2_shell.bin'],
      registryKeys: ['HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run'],
      dangerousApiCalls: ['VirtualAlloc', 'WriteProcessMemory', 'CreateRemoteThread'],
      networkActivityRisk: 'High',
    },
    remediationSteps: [
      'กักกันหรือลบไฟล์นี้ออกจากเครื่องทันที ห้ามรันไฟล์โดยเด็ดขาด',
      'ตัดการเชื่อมต่อเครือข่ายอินเทอร์เน็ตเพื่อป้องกันการแพร่กระจายไปยังเครื่องอื่นในวง LAN',
      'ตรวจสอบ Task Scheduler และ Registry Run เพื่อลบส่วนตกค้าง',
    ],
    scanDurationMs: 380,
    timestamp: new Date(Date.now() - 1000 * 60 * 35).toISOString(),
    quarantined: true,
  },
];

export default function App() {
  const [reports, setReports] = useState<ScanReport[]>(() => {
    const saved = localStorage.getItem('aegisshield_scan_reports_v2');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_REPORTS;
      }
    }
    return INITIAL_REPORTS;
  });

  const [isScanning, setIsScanning] = useState(false);
  const [scanningFilename, setScanningFilename] = useState('');
  const [activeModalReport, setActiveModalReport] = useState<ScanReport | null>(null);
  const [lang, setLang] = useState<'th' | 'en'>('th');
  const [hasApiKey, setHasApiKey] = useState(false);
  const [engineStatus, setEngineStatus] = useState('online');

  // Check health and server API capabilities on mount
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        if (data.hasApiKey) setHasApiKey(true);
        if (data.status) setEngineStatus(data.status);
      })
      .catch(() => {
        setEngineStatus('client-fallback');
      });
  }, []);

  // Save reports to localStorage
  useEffect(() => {
    localStorage.setItem('aegisshield_scan_reports_v2', JSON.stringify(reports));
  }, [reports]);

  // Main Scan Handler
  const handleScanFile = async (fileData: {
    filename: string;
    content: string;
    isBase64: boolean;
    fileSize: number;
  }) => {
    setIsScanning(true);
    setScanningFilename(fileData.filename);

    const startTime = Date.now();

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: fileData.filename,
          fileContent: fileData.content,
          isBase64: fileData.isBase64,
          fileSize: fileData.fileSize,
        }),
      });

      if (!response.ok) {
        throw new Error(`Server returned HTTP ${response.status}`);
      }

      const report: ScanReport = await response.json();

      // Update state and immediately show modal report
      setReports((prev) => [report, ...prev]);
      setActiveModalReport(report);
    } catch (err) {
      console.warn('Backend API scan error, running client-side engine:', err);

      // Client-side fallback engine so the app never fails
      let bytes: Uint8Array;
      let decodedText = fileData.content;
      if (fileData.isBase64) {
        const bin = atob(fileData.content);
        bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        decodedText = bin.slice(0, 32768);
      } else {
        const enc = new TextEncoder();
        bytes = enc.encode(fileData.content);
      }

      const entropyScore = calculateShannonEntropy(bytes);
      const entropyBlocks = calculateBlockEntropy(bytes, 16);
      const magicInfo = detectMagicHeader(bytes, fileData.filename);
      const indicators = inspectStringsAndHeuristics(decodedText);
      const hashes = generateHashes(bytes);

      const hasEicar = indicators.suspiciousStrings.some((s) => s.includes('EICAR'));
      const evalResult = evaluateThreatScore({
        entropy: entropyScore,
        isExecutable: magicInfo.isExecutable,
        mismatchRisk: magicInfo.mismatchRisk,
        suspiciousStringCount: indicators.suspiciousStrings.length,
        dangerousApiCount: indicators.dangerousApiCalls.length,
        registryCount: indicators.registryKeys.length,
        hasEicar,
      });

      const mitreAttacks = mapMitreAttacks(indicators, magicInfo.mismatchRisk, entropyScore);
      const remediation = generateRemediation(evalResult.severity, evalResult.family);

      const fileStructure = parseFileStructure(bytes, fileData.filename, decodedText);
      const { lines: annotatedLines, location: malwareLocation } = disassembleAndAnnotateLines(decodedText, fileData.filename);
      const virusCategory = classifyVirusCategory(evalResult.family, fileData.filename, evalResult.severity === 'clean');

      const fallbackReport: ScanReport = {
        id: `scan-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        filename: fileData.filename,
        fileSize: fileData.fileSize || bytes.length,
        fileType: fileData.filename.split('.').pop()?.toUpperCase() || 'UNKNOWN',
        detectedMime: magicInfo.mime,
        magicBytes: magicInfo.magicHex,
        md5: hashes.md5,
        sha256: hashes.sha256,
        entropyScore,
        entropyVerdict: entropyScore > 7.2 ? 'High (Packer/Crypto)' : entropyScore > 5 ? 'Moderate' : 'Low',
        entropyBlocks,
        severity: evalResult.severity,
        threatScore: evalResult.score,
        malwareFamily: evalResult.family,
        virusClassification: virusCategory,
        fileStructure,
        annotatedLines,
        malwareLocation,
        aiForensics: {
          summaryTh: `ระบบ AI Heuristics ตรวจสอบไฟล์ "${fileData.filename}" พบระดับความเสี่ยง ${evalResult.score}/100 จัดอยู่ในประเภท ${evalResult.family} มีค่า Shannon Entropy ${entropyScore}`,
          summaryEn: `AI Heuristics inspected "${fileData.filename}". Assigned threat score ${evalResult.score}/100 as ${evalResult.family} with entropy ${entropyScore}.`,
          suspicionReasons: [
            magicInfo.mismatchRisk ? 'ตรวจพบนามสกุลไฟล์ไม่ตรงกับ Magic Header จริง' : 'ตรวจสอบโครงสร้างและลายเซ็นของไฟล์แล้ว',
            ...indicators.suspiciousStrings.slice(0, 3),
          ],
          confidenceScore: 92,
          potentialDamage: evalResult.severity === 'clean' ? 'ไม่มีความเสียหาย' : 'อาจส่งผลต่อความปลอดภัยและการทำงานของระบบ',
          quarantineRecommended: evalResult.severity === 'malicious' || evalResult.severity === 'critical',
          behavioralClassification: evalResult.family,
        },
        mitreAttacks,
        indicators,
        remediationSteps: remediation,
        scanDurationMs: Date.now() - startTime,
        timestamp: new Date().toISOString(),
        quarantined: evalResult.severity === 'critical',
        rawContentSnippet: decodedText.slice(0, 8192),
      };

      setReports((prev) => [fallbackReport, ...prev]);
      setActiveModalReport(fallbackReport);
    } finally {
      setIsScanning(false);
    }
  };

  const handleToggleQuarantine = (id: string) => {
    setReports((prev) =>
      prev.map((r) => (r.id === id ? { ...r, quarantined: !r.quarantined } : r))
    );
    if (activeModalReport && activeModalReport.id === id) {
      setActiveModalReport((prev) => (prev ? { ...prev, quarantined: !prev.quarantined } : null));
    }
  };

  const handleDeleteReport = (id: string) => {
    setReports((prev) => prev.filter((r) => r.id !== id));
    if (activeModalReport?.id === id) {
      setActiveModalReport(null);
    }
  };

  const handleResetDemo = () => {
    setReports(INITIAL_REPORTS);
  };

  const threatsCount = reports.filter(
    (r) => r.severity === 'malicious' || r.severity === 'critical'
  ).length;

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col selection:bg-cyan-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        engineStatus={engineStatus}
        hasApiKey={hasApiKey}
        threatCount={threatsCount}
        onResetDemo={handleResetDemo}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'th' ? 'en' : 'th'))}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Key Metrics Stats */}
        <DashboardStats reports={reports} lang={lang} />

        {/* Real-time File Upload & Deep Scan Zone */}
        <FileUploader
          onScanFile={handleScanFile}
          isScanning={isScanning}
          lang={lang}
        />

        {/* Threat Radar & Distribution */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <div className="lg:col-span-1">
            <ThreatRadarWidget reports={reports} lang={lang} />
          </div>

          <div className="lg:col-span-2">
            <ScanHistoryTable
              reports={reports}
              onSelectReport={(r) => setActiveModalReport(r)}
              onDeleteReport={handleDeleteReport}
              lang={lang}
            />
          </div>
        </div>
      </main>

      {/* Scanning Stage Progress Overlay */}
      {isScanning && (
        <ScanningOverlay filename={scanningFilename} lang={lang} />
      )}

      {/* Detailed Scan Summary Report Modal */}
      {activeModalReport && (
        <ScanResultModal
          report={activeModalReport}
          onClose={() => setActiveModalReport(null)}
          onToggleQuarantine={handleToggleQuarantine}
          lang={lang}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500 font-mono">
        <p>
          AegisShield AI • Next-Gen Real-time Neural File & Threat Scanner • MITRE ATT&CK Matrix Compatible
        </p>
      </footer>
    </div>
  );
}
