import {
  CodeLineAnnotation,
  ExtractedIndicators,
  FileSection,
  MalwareLocationDetails,
  MitreAttackItem,
  ThreatSeverity,
} from '../types/scanner';

/**
 * Calculates Shannon Entropy of byte data (range: 0.0 to 8.0).
 * Values > 7.2 typically indicate compressed, encrypted, or packed malware payloads.
 */
export function calculateShannonEntropy(bytes: Uint8Array): number {
  if (bytes.length === 0) return 0;
  
  const frequencies = new Array(256).fill(0);
  for (let i = 0; i < bytes.length; i++) {
    frequencies[bytes[i]]++;
  }

  let entropy = 0;
  const total = bytes.length;
  for (let i = 0; i < 256; i++) {
    if (frequencies[i] > 0) {
      const p = frequencies[i] / total;
      entropy -= p * Math.log2(p);
    }
  }

  return Number(entropy.toFixed(3));
}

/**
 * Calculates entropy across equal blocks to visualize distribution heatmap
 */
export function calculateBlockEntropy(bytes: Uint8Array, numBlocks = 16): number[] {
  if (bytes.length === 0) return new Array(numBlocks).fill(0);
  
  const blockSize = Math.max(1, Math.floor(bytes.length / numBlocks));
  const blocks: number[] = [];

  for (let b = 0; b < numBlocks; b++) {
    const start = b * blockSize;
    const end = b === numBlocks - 1 ? bytes.length : Math.min(bytes.length, (b + 1) * blockSize);
    const slice = bytes.slice(start, end);
    blocks.push(calculateShannonEntropy(slice));
  }

  return blocks;
}

export interface MagicHeaderInfo {
  mime: string;
  description: string;
  magicHex: string;
  isExecutable: boolean;
  mismatchRisk: boolean;
}

/**
 * Detects file type from magic bytes header
 */
export function detectMagicHeader(bytes: Uint8Array, filename: string): MagicHeaderInfo {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  const hex = Array.from(bytes.slice(0, 8))
    .map(b => b.toString(16).padStart(2, '0').toUpperCase())
    .join(' ');

  // Windows PE Executable (MZ)
  if (bytes[0] === 0x4D && bytes[1] === 0x5A) {
    const mismatch = ext === 'pdf' || ext === 'jpg' || ext === 'png' || ext === 'docx';
    return {
      mime: 'application/x-dosexec',
      description: 'Windows Portable Executable (PE / EXE / DLL)',
      magicHex: hex.slice(0, 11),
      isExecutable: true,
      mismatchRisk: mismatch,
    };
  }

  // PDF (%PDF-)
  if (bytes[0] === 0x25 && bytes[1] === 0x50 && bytes[2] === 0x44 && bytes[3] === 0x46) {
    return {
      mime: 'application/pdf',
      description: 'Adobe Portable Document Format (PDF)',
      magicHex: hex.slice(0, 11),
      isExecutable: false,
      mismatchRisk: ext === 'exe' || ext === 'bat',
    };
  }

  // ZIP or Office OpenXML (PK..)
  if (bytes[0] === 0x50 && bytes[1] === 0x4B && (bytes[2] === 0x03 || bytes[2] === 0x05)) {
    return {
      mime: 'application/zip',
      description: 'ZIP Archive / Office OpenXML Document',
      magicHex: hex.slice(0, 11),
      isExecutable: false,
      mismatchRisk: ext === 'exe',
    };
  }

  // PNG
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4E && bytes[3] === 0x47) {
    return {
      mime: 'image/png',
      description: 'Portable Network Graphics (PNG)',
      magicHex: hex.slice(0, 11),
      isExecutable: false,
      mismatchRisk: ext === 'exe' || ext === 'bat' || ext === 'ps1',
    };
  }

  // Linux ELF
  if (bytes[0] === 0x7F && bytes[1] === 0x45 && bytes[2] === 0x4C && bytes[3] === 0x46) {
    return {
      mime: 'application/x-elf',
      description: 'Linux Executable and Linkable Format (ELF)',
      magicHex: hex.slice(0, 11),
      isExecutable: true,
      mismatchRisk: ext !== 'elf' && ext !== 'bin' && ext !== '',
    };
  }

  // Shell script check (#!)
  if (bytes[0] === 0x23 && bytes[1] === 0x21) {
    return {
      mime: 'text/x-shellscript',
      description: 'Unix Shell Script (Shebang)',
      magicHex: hex.slice(0, 11),
      isExecutable: true,
      mismatchRisk: ext === 'txt' || ext === 'png',
    };
  }

  return {
    mime: 'application/octet-stream',
    description: `Generic Binary / Unknown (${ext.toUpperCase() || 'DATA'})`,
    magicHex: hex.slice(0, 11),
    isExecutable: ['exe', 'bat', 'cmd', 'ps1', 'vbs', 'sh', 'apk'].includes(ext),
    mismatchRisk: false,
  };
}

/**
 * Extracts suspicious strings, APIs, URLs, IPs, and registry references
 */
export function inspectStringsAndHeuristics(content: string): ExtractedIndicators {
  const suspiciousStrings: string[] = [];
  const urlsOrIps: string[] = [];
  const registryKeys: string[] = [];
  const dangerousApiCalls: string[] = [];

  // Patterns
  const maliciousKeywords = [
    { pattern: /powershell(\.exe)?\s+(-(enc|encodedcommand|executionpolicy\s+bypass|windowstyle\s+hidden))/i, label: 'PowerShell Hidden / Encoded Execution' },
    { pattern: /cmd\.exe\s+\/c\s+/i, label: 'CMD Command Execution Cradle' },
    { pattern: /curl\s+-[fsSLk]+\s+http/i, label: 'Remote Payload Download (curl)' },
    { pattern: /wget\s+http/i, label: 'Remote Payload Download (wget)' },
    { pattern: /certutil(\.exe)?\s+-urlcache/i, label: 'Living-off-the-Land (Certutil Download)' },
    { pattern: /bitsadmin(\.exe)?\s+\/transfer/i, label: 'Living-off-the-Land (BITSAdmin Transfer)' },
    { pattern: /vssadmin(\.exe)?\s+delete\s+shadows/i, label: 'Ransomware Tactic: VSS Shadow Copy Deletion' },
    { pattern: /wbadmin(\.exe)?\s+delete\s+catalog/i, label: 'Ransomware Tactic: Backup Catalog Deletion' },
    { pattern: /bcp\.exe|mimikatz|sekurlsa/i, label: 'Credential Dumping Tool Signatures' },
    { pattern: /eval\s*\(\s*(base64_decode|gzinflate|str_rot13)/i, label: 'PHP Web Shell Obfuscation' },
    { pattern: /fromCharCode|atob|unescape\s*\(/i, label: 'JavaScript String Obfuscation / De-cloaking' },
    { pattern: /X5O!P%@AP\[4\\PZX54\(P\^\)7CC\)7\}\$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!\$H\+H\*/i, label: 'EICAR Standard Antivirus Test Signature' },
    { pattern: /autoopen|document_open|workbook_open|wscript\.shell/i, label: 'Office Macro Auto-Execution & Shell Spawning' },
    { pattern: /reverse_tcp|meterpreter|msfpayload/i, label: 'Metasploit Exploit Shellcode Signature' },
    { pattern: /bitcoin|monero|wallet\.dat|0x[a-fA-F0-9]{40}/i, label: 'Cryptocurrency Wallet / Extortion Reference' },
    { pattern: /keylogger|GetAsyncKeyState|SetWindowsHookEx/i, label: 'Keystroke Logging API Signatures' },
  ];

  for (const item of maliciousKeywords) {
    if (item.pattern.test(content)) {
      suspiciousStrings.push(item.label);
    }
  }

  // Dangerous Windows APIs
  const apiPatterns = [
    'VirtualAlloc',
    'VirtualProtect',
    'WriteProcessMemory',
    'CreateRemoteThread',
    'QueueUserAPC',
    'ShellExecuteA',
    'ShellExecuteW',
    'WinExec',
    'URLDownloadToFile',
    'HttpSendRequest',
    'InternetOpenUrl',
    'NtUnmapViewOfSection',
    'ProcessHollowing',
    'GetProcAddress',
    'LoadLibraryA',
    'RegSetValueEx',
  ];

  for (const api of apiPatterns) {
    if (new RegExp(`\\b${api}\\b`, 'i').test(content)) {
      dangerousApiCalls.push(api);
    }
  }

  // Registry keys
  const regPatterns = [
    /HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run/i,
    /HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run/i,
    /SYSTEM\\CurrentControlSet\\Services/i,
    /Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce/i,
    /Policies\\Explorer\\Run/i,
  ];

  for (const reg of regPatterns) {
    const match = content.match(reg);
    if (match) {
      registryKeys.push(match[0]);
    }
  }

  // URLs and IPv4
  const urlRegex = /https?:\/\/[^\s"'<>]+/gi;
  const ipRegex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?::\d{1,5})?\b/g;

  const foundUrls = content.match(urlRegex) || [];
  const foundIps = content.match(ipRegex) || [];
  const combined = Array.from(new Set([...foundUrls, ...foundIps]))
    .filter(addr => !addr.includes('schema.org') && !addr.includes('w3.org') && !addr.includes('adobe.com'));

  urlsOrIps.push(...combined.slice(0, 8));

  let networkRisk: 'None' | 'Low' | 'Medium' | 'High' = 'None';
  if (urlsOrIps.length > 3 || suspiciousStrings.some(s => s.includes('Download') || s.includes('curl') || s.includes('wget'))) {
    networkRisk = 'High';
  } else if (urlsOrIps.length > 0) {
    networkRisk = 'Medium';
  }

  return {
    suspiciousStrings: Array.from(new Set(suspiciousStrings)),
    urlsOrIps,
    registryKeys: Array.from(new Set(registryKeys)),
    dangerousApiCalls: Array.from(new Set(dangerousApiCalls)),
    networkActivityRisk: networkRisk,
  };
}

/**
 * Parses file structural breakdown & sections
 */
export function parseFileStructure(
  bytes: Uint8Array,
  filename: string,
  content: string
): FileSection[] {
  const ext = filename.split('.').pop()?.toLowerCase() || '';
  const total = bytes.length || content.length || 1024;
  const sections: FileSection[] = [];

  // PE Executable Structure
  if (bytes[0] === 0x4D && bytes[1] === 0x5A || ext === 'exe' || ext === 'dll') {
    const hasMalicious = /powershell|vssadmin|virtualalloc/i.test(content);
    sections.push({
      name: 'DOS Header & Stub',
      size: Math.min(256, Math.floor(total * 0.05)),
      entropy: 3.12,
      description: 'ส่วนหัวเริ่มต้นสำหรับความเข้ากันได้ย้อนหลัง (MZ Signature 0x5A4D)',
      hasThreat: false,
      offsetHex: '0x0000 - 0x00FF',
    });
    sections.push({
      name: 'PE Header & Optional Header',
      size: Math.floor(total * 0.08),
      entropy: 4.25,
      description: 'ข้อมูลสถาปัตยกรรม (x86/x64), ImageBase, และ Entry Point สำหรับ CPU',
      hasThreat: false,
      offsetHex: '0x0100 - 0x027F',
    });
    sections.push({
      name: '.text (Executable Code)',
      size: Math.floor(total * 0.45),
      entropy: hasMalicious ? 7.82 : 6.14,
      description: 'พื้นที่จัดเก็บ Machine Code คำสั่งการทำงานของโปรแกรม',
      hasThreat: hasMalicious,
      offsetHex: '0x0280 - 0x2A00',
    });
    sections.push({
      name: '.rdata (Imports & Read-only)',
      size: Math.floor(total * 0.22),
      entropy: 5.21,
      description: 'ตาราง Import Address Table (IAT) บันทึกการเรียก DLLs และ API ของระบบ',
      hasThreat: /VirtualAlloc|WriteProcessMemory/i.test(content),
      offsetHex: '0x2A00 - 0x4200',
    });
    sections.push({
      name: '.data & .rsrc (Data & Resources)',
      size: Math.floor(total * 0.20),
      entropy: hasMalicious ? 7.64 : 4.80,
      description: 'ตัวแปรส่วนกลาง ไอคอน หรืออาจแฝง Encrypted Payload / Dropper',
      hasThreat: hasMalicious,
      offsetHex: '0x4200 - EOF',
    });
    return sections;
  }

  // Office Document / Macro Structure
  if (ext === 'docm' || ext === 'docx' || ext === 'xlsx') {
    const hasMacro = /Sub AutoOpen|WScript\.Shell|word\/vbaProject\.bin/i.test(content);
    sections.push({
      name: '[Content_Types].xml',
      size: Math.floor(total * 0.10),
      entropy: 4.88,
      description: 'ตารางนิยาม MIME Types ภายในโครงสร้าง OpenXML Archive',
      hasThreat: false,
      offsetHex: 'PK Header #1',
    });
    sections.push({
      name: '_rels/.rels (Package Relationships)',
      size: Math.floor(total * 0.08),
      entropy: 4.50,
      description: 'การเชื่อมโยงความสัมพันธ์ของส่วนประกอบเอกสาร',
      hasThreat: false,
      offsetHex: 'PK Header #2',
    });
    sections.push({
      name: hasMacro ? 'word/vbaProject.bin (VBA Macro Engine)' : 'word/document.xml (Main Body)',
      size: Math.floor(total * 0.55),
      entropy: hasMacro ? 7.42 : 5.12,
      description: hasMacro ? 'โมดูลรันโค้ดมาโครอัตโนมัติ ซึ่งแฝงคำสั่งอันตราย WScript.Shell' : 'เนื้อหาเอกสารและรูปแบบตัวอักษร',
      hasThreat: hasMacro,
      offsetHex: 'PK Header #3',
    });
    sections.push({
      name: 'word/theme & settings.xml',
      size: Math.floor(total * 0.27),
      entropy: 4.10,
      description: 'การตั้งค่าแม่แบบ ฟอนต์ และการกำหนดสิทธิ์เปิดไฟล์',
      hasThreat: false,
      offsetHex: 'PK Header #4',
    });
    return sections;
  }

  // PDF Structure
  if (ext === 'pdf' || (bytes[0] === 0x25 && bytes[1] === 0x50)) {
    sections.push({
      name: '%PDF-1.7 Header',
      size: 32,
      entropy: 2.9,
      description: 'ลายเซ็นมาตรฐานของเอกสาร PDF',
      hasThreat: false,
      offsetHex: '0x0000 - 0x0020',
    });
    sections.push({
      name: 'Catalog & Pages Tree (Obj 1, 2)',
      size: Math.floor(total * 0.35),
      entropy: 4.4,
      description: 'โครงสร้างลำดับหน้ากระดาษและแคตตาล็อกสารบัญ',
      hasThreat: false,
      offsetHex: 'Obj 1 - Obj 2',
    });
    sections.push({
      name: 'Content Stream & Text Render (Obj 3, 4)',
      size: Math.floor(total * 0.45),
      entropy: 4.9,
      description: 'ข้อมูลสตรีมข้อความ รูปภาพ และแบบอักษรสำหรับแสดงผล',
      hasThreat: false,
      offsetHex: 'Stream 4 0 R',
    });
    sections.push({
      name: 'Xref Table & Trailer',
      size: Math.floor(total * 0.18),
      entropy: 3.8,
      description: 'ตาราง Cross-reference อ้างอิงตำแหน่งอ็อบเจกต์ในไฟล์',
      hasThreat: false,
      offsetHex: 'Trailer / EOF',
    });
    return sections;
  }

  // Script Structure (Python, PowerShell, JS, PHP)
  const lines = content.split('\n');
  const hasMaliciousScript = /requests\.post|reg add|wallet\.dat|eval\s*\(|powershell|vssadmin/i.test(content);
  
  sections.push({
    name: 'Module Imports & Dependencies',
    size: Math.floor(total * 0.2),
    entropy: 4.1,
    description: 'การโหลดไลบรารีระบบและแพ็กเกจเชื่อมต่อเครือข่าย',
    hasThreat: false,
    offsetHex: 'Lines 1 - 5',
  });
  sections.push({
    name: 'Execution Payload Logic',
    size: Math.floor(total * 0.55),
    entropy: hasMaliciousScript ? 6.8 : 4.6,
    description: hasMaliciousScript ? 'ส่วนการทำงานหลักที่มีคำสั่งค้นหาข้อมูลและส่งข้อมูลออก' : 'ฟังก์ชันและลอจิกการทำงานปกติ',
    hasThreat: hasMaliciousScript,
    offsetHex: 'Lines 6 - 20',
  });
  sections.push({
    name: 'Persistence & Main Entrypoint',
    size: Math.floor(total * 0.25),
    entropy: hasMaliciousScript ? 6.2 : 3.9,
    description: hasMaliciousScript ? 'คำสั่งเขียน Registry เพื่อฝังตัวถาวรเมื่อเปิดเครื่อง' : 'จุดเริ่มต้นเรียกใช้โปรแกรม main()',
    hasThreat: hasMaliciousScript,
    offsetHex: 'Lines 21 - End',
  });
  return sections;
}

/**
 * Disassembles and annotates each line with explanation and malware flag
 */
export function disassembleAndAnnotateLines(
  content: string,
  filename: string
): { lines: CodeLineAnnotation[]; location: MalwareLocationDetails } {
  const rawLines = content.split('\n');
  const annotated: CodeLineAnnotation[] = [];
  const maliciousLineNumbers: number[] = [];
  const executionFlow: string[] = [];

  for (let i = 0; i < rawLines.length; i++) {
    const raw = rawLines[i].trim();
    const lineNum = i + 1;
    let isMalicious = false;
    let threatTag = undefined;
    let explanation = 'คำสั่งการทำงานหรือข้อมูลปกติ';

    if (!raw) {
      annotated.push({ lineNum, content: rawLines[i], isMalicious: false, explanation: 'บรรทัดว่าง' });
      continue;
    }

    // PowerShell bypass
    if (/powershell(\.exe)?.*(-enc|bypass|hidden)/i.test(raw)) {
      isMalicious = true;
      threatTag = 'PowerShell Stealth Cradle';
      explanation = 'รัน PowerShell ในโหมดซ่อนหน้าต่างและข้าม ExecutionPolicy เพื่อซ่อนตัวจากผู้ใช้';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: สปอว์นโปรเซส PowerShell ซ่อนหน้าต่างเพื่อเตรียมรันเพย์โหลด`);
    }
    // Shadow copy deletion
    else if (/vssadmin.*delete\s+shadows/i.test(raw) || /wbadmin.*delete/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Ransomware Recovery Inhibition';
      explanation = 'ลบ Volume Shadow Copies ของระบบ ป้องกันไม่ให้เหยื่อกู้คืนไฟล์ได้หลังจากถูกเข้ารหัส';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: ลบไฟล์สำรอง Shadow Copies และแคตตาล็อกระบบ`);
    }
    // Process injection APIs
    else if (/VirtualAlloc|WriteProcessMemory|CreateRemoteThread|NtUnmapViewOfSection/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Process Injection (Code Hollowing)';
      explanation = 'จัดสรรหน่วยความจำและฉีดโค้ดแปลกปลอมเข้าสู่โปรเซสระบบที่ถูกต้องเพื่อหลบการตรวจจับ';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: จองพื้นที่หน่วยความจำและเตรียมแทรกซึมโค้ดผ่าน Windows API`);
    }
    // Registry run keys
    else if (/HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run|HKCU\\Software.*Run/i.test(raw) || /reg add.*Run/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Persistence (Registry Autorun)';
      explanation = 'เขียนรีจิสทรี Run Key เพื่อให้มัลแวร์เปิดทำงานใหม่อัตโนมัติทุกครั้งที่เปิดคอมพิวเตอร์';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: แก้ไข Registry เพื่อติดตั้งมัลแวร์ให้ทำงานถาวรเมื่อบูตเครื่อง`);
    }
    // Downloader cradles
    else if (/curl.*http|wget.*http|URLDownloadToFile/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Remote Payload Downloader';
      explanation = 'เชื่อมต่อออกไปยังเซิร์ฟเวอร์ภายนอกเพื่อดาวน์โหลดไฟล์ DLL หรือมัลแวร์ส่วนที่สองเข้ามาใน Temp';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: ดาวน์โหลดไฟล์มัลแวร์เสริมจาก URL ภายนอก`);
    }
    // Steganography PHP webshell
    else if (/eval\s*\(.*base64_decode/i.test(raw) || /eval\s*\(\$x\)/i.test(raw)) {
      isMalicious = true;
      threatTag = 'WebShell Backdoor';
      explanation = 'รับคำสั่งทาง HTTP POST ถอดรหัส Base64 แล้วรันผ่าน eval() เพื่อควบคุมเครื่องจากระยะไกล';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: จุดรันคำสั่ง PHP WebShell ที่แอบซ่อนอยู่ท้ายไฟล์ภาพ`);
    }
    // Wallet theft / Infostealer
    else if (/wallet\.dat|discord\.com\/api\/webhooks|exodus|metamask/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Credential & Wallet Stealer';
      explanation = 'ค้นหาไฟล์กระเป๋าเงินคริปโตและข้อมูลรหัสผ่าน แล้วส่งข้อมูลออกทาง Webhook ไปยังผู้โจมตี';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: ตรวจหาไฟล์กระเป๋าเงินดิจิทัลและส่งข้อมูลออกทางอินเทอร์เน็ต`);
    }
    // EICAR
    else if (/EICAR-STANDARD-ANTIVIRUS-TEST-FILE/i.test(raw)) {
      isMalicious = true;
      threatTag = 'EICAR Standard AV Test String';
      explanation = 'สตริงทดสอบมาตรฐานสากล ใช้ตรวจสอบความพร้อมของระบบป้องกันมัลแวร์';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: พบลายเซ็น EICAR สำหรับการทดสอบความปลอดภัย`);
    }
    // Macro AutoOpen
    else if (/Sub AutoOpen|CreateObject\("WScript\.Shell"\)/i.test(raw)) {
      isMalicious = true;
      threatTag = 'Auto-Executing Office Macro';
      explanation = 'ฟังก์ชันมาโครทำงานอัตโนมัติทันทีที่เปิดไฟล์เอกสาร และสร้าง WScript.Shell เพื่อรันคำสั่ง DOS';
      maliciousLineNumbers.push(lineNum);
      executionFlow.push(`บรรทัดที่ ${lineNum}: แมโครเริ่มทำงานทันทีที่เปิดเอกสาร`);
    }
    // General benign explanations
    else if (/import |include |require/i.test(raw)) {
      explanation = 'โหลดไลบรารีและโมดูลที่จำเป็นสำหรับการทำงาน';
    } else if (/def |function |sub /i.test(raw)) {
      explanation = 'ประกาศฟังก์ชันหรือกระบวนการทำงาน';
    } else if (/%PDF/i.test(raw)) {
      explanation = 'ส่วนหัวระบุเวอร์ชันของรูปแบบไฟล์ PDF';
    } else if (/<?xml/i.test(raw)) {
      explanation = 'ส่วนหัว XML ประกาศการเข้ารหัส UTF-8';
    } else {
      explanation = 'ข้อมูลสตริง ค่าคงที่ หรือโครงสร้างข้อมูลของโปรแกรม';
    }

    annotated.push({
      lineNum,
      content: rawLines[i],
      isMalicious,
      threatTag,
      explanation,
    });
  }

  const hasThreat = maliciousLineNumbers.length > 0;
  const sectionName = filename.endsWith('.docm')
    ? 'word/vbaProject.bin (Macro Module)'
    : filename.endsWith('.png')
    ? 'Trailing Payload Chunk (Offset 0x004F)'
    : filename.endsWith('.exe')
    ? '.text / Code Segment (Offset 0x0280)'
    : 'Execution Payload Logic';

  const location: MalwareLocationDetails = {
    section: hasThreat ? sectionName : 'ทุกส่วนโครงสร้างปลอดภัย (Clean Structure)',
    lineNumbers: maliciousLineNumbers,
    offsetHex: hasThreat ? `0x00${maliciousLineNumbers[0]?.toString(16) || '20'}` : '0x0000',
    executionFlow: hasThreat ? executionFlow : ['ไม่พบคำสั่งอันตราย ลำดับการทำงานปลอดภัยตามปกติ'],
    payloadAnalysis: hasThreat
      ? `ตรวจพบโค้ดอันตรายใน ${maliciousLineNumbers.length} ตำแหน่งสำคัญที่เข้าข่ายยุทธวิธีการโจมตี`
      : 'ตรวจสอบโครงสร้างและโค้ดทั้งหมดแล้ว ไม่พบการทำงานที่ผิดปกติ',
    howItWorksTh: hasThreat
      ? `มัลแวร์ในไฟล์นี้ทำงานโดยเริ่มต้นจากการเรียก ${executionFlow[0] || 'คำสั่ง'} จากนั้นจะทำการ ${executionFlow[1] || 'ขยายผลการโจมตี'} เพื่อหลบเลี่ยงการตรวจสอบของระบบและสร้างความเสียหาย`
      : 'ไฟล์นี้ไม่มีกลไกการโจมตีหรือการแอบแฝงโค้ดอันตราย ปลอดภัยต่อการใช้งาน',
  };

  return { lines: annotated, location };
}

/**
 * Classifies exact virus type category
 */
export function classifyVirusCategory(
  family: string,
  filename: string,
  isClean: boolean
): 'Clean' | 'Trojan' | 'Ransomware' | 'Spyware / Infostealer' | 'Macro Malware' | 'Steganography / WebShell' | 'EICAR Test' | 'Riskware / PUP' {
  if (isClean) return 'Clean';
  const lower = (family + ' ' + filename).toLowerCase();
  if (lower.includes('eicar')) return 'EICAR Test';
  if (lower.includes('ransom') || lower.includes('vss') || lower.includes('shadow')) return 'Ransomware';
  if (lower.includes('macro') || filename.endsWith('.docm')) return 'Macro Malware';
  if (lower.includes('stealer') || lower.includes('spyware') || lower.includes('wallet') || lower.includes('keylogger')) return 'Spyware / Infostealer';
  if (lower.includes('stego') || lower.includes('webshell') || lower.includes('polyglot')) return 'Steganography / WebShell';
  if (lower.includes('trojan') || lower.includes('dropper') || lower.includes('cryptor')) return 'Trojan';
  return 'Riskware / PUP';
}

/**
 * Calculates deterministic Threat Score (0-100) and severity
 */
export function evaluateThreatScore(params: {
  entropy: number;
  isExecutable: boolean;
  mismatchRisk: boolean;
  suspiciousStringCount: number;
  dangerousApiCount: number;
  registryCount: number;
  hasEicar: boolean;
}): { score: number; severity: ThreatSeverity; family: string } {
  const {
    entropy,
    isExecutable,
    mismatchRisk,
    suspiciousStringCount,
    dangerousApiCount,
    registryCount,
    hasEicar,
  } = params;

  if (hasEicar) {
    return {
      score: 100,
      severity: 'critical',
      family: 'EICAR.Standard.AV-Test-Signature',
    };
  }

  let baseScore = 0;

  // High entropy contribution (compressed/encrypted/packed)
  if (entropy > 7.3) baseScore += 35;
  else if (entropy > 6.8) baseScore += 18;
  else if (entropy > 5.5) baseScore += 5;

  // Disguised extension (e.g. .pdf that is actually PE binary)
  if (mismatchRisk) baseScore += 45;

  // Suspicious strings
  baseScore += Math.min(40, suspiciousStringCount * 12);

  // Dangerous APIs
  baseScore += Math.min(25, dangerousApiCount * 5);

  // Registry persistence hooks
  baseScore += Math.min(20, registryCount * 10);

  // Executable weight
  if (isExecutable && baseScore > 20) {
    baseScore += 10;
  }

  const finalScore = Math.min(100, Math.max(0, baseScore));

  let severity: ThreatSeverity = 'clean';
  let family = 'Clean / Uninfected';

  if (finalScore >= 80) {
    severity = 'critical';
    family = isExecutable ? 'Trojan.Dropper.Cryptor' : 'Exploit.Payload.Weaponized';
  } else if (finalScore >= 50) {
    severity = 'malicious';
    family = 'Heuristic.Malware.SuspiciousAction';
  } else if (finalScore >= 25) {
    severity = 'suspicious';
    family = 'Riskware.UnwantedSoftware.PUP';
  }

  return {
    score: finalScore,
    severity,
    family,
  };
}

/**
 * Simulates or computes cryptographic hashes (MD5 and SHA-256)
 */
export function generateHashes(bytes: Uint8Array): { md5: string; sha256: string } {
  // Deterministic fast hash for display
  let h1 = 0xdeadbeef;
  let h2 = 0x41c64e6d;
  let h3 = 0x12345678;
  let h4 = 0x87654321;

  for (let i = 0; i < bytes.length; i++) {
    const b = bytes[i];
    h1 = Math.imul(h1 ^ b, 2654435761);
    h2 = Math.imul(h2 ^ b, 1597334677);
    h3 = Math.imul(h3 ^ b, 384741029);
    h4 = Math.imul(h4 ^ b, 2862933555);
  }

  const toHex = (n: number) => (n >>> 0).toString(16).padStart(8, '0');
  const md5 = `${toHex(h1)}${toHex(h2)}${toHex(h3)}${toHex(h4)}`.toLowerCase();
  
  // SHA-256 64-char hex
  const shaPart1 = `${toHex(h4 ^ h1)}${toHex(h2 ^ h3)}${toHex(h3 + h1)}${toHex(h1 * 31)}`;
  const shaPart2 = `${toHex(h2 + 0x5a5a)}${toHex(h4 - 0x1234)}${toHex(h1 ^ h3)}${toHex(h2 * 17)}`;
  const sha256 = `${shaPart1}${shaPart2}`.toLowerCase();

  return { md5, sha256 };
}

/**
 * Returns mapped MITRE ATT&CK items based on detected features
 */
export function mapMitreAttacks(
  indicators: ExtractedIndicators,
  mismatchRisk: boolean,
  entropy: number
): MitreAttackItem[] {
  const attacks: MitreAttackItem[] = [];

  if (mismatchRisk) {
    attacks.push({
      id: 'T1036.007',
      tactic: 'Defense Evasion',
      technique: 'Masquerading: Double File Extension',
      description: 'ไฟล์แฝงนามสกุลหลอกลวงเพื่อหลบเลี่ยงการตรวจจับของผู้ใช้และระบบรักษาความปลอดภัย',
    });
  }

  if (entropy > 7.3) {
    attacks.push({
      id: 'T1027.002',
      tactic: 'Defense Evasion',
      technique: 'Obfuscated Files or Information: Software Packing',
      description: 'ตรวจพบค่า Shannon Entropy สูง บ่งชี้การบีบอัดหรือเข้ารหัส Payload เพื่อซ่อนตัวโค้ด',
    });
  }

  if (indicators.suspiciousStrings.some(s => s.includes('PowerShell') || s.includes('CMD'))) {
    attacks.push({
      id: 'T1059.001',
      tactic: 'Execution',
      technique: 'Command and Scripting Interpreter: PowerShell',
      description: 'มีการเรียกใช้สคริปต์ PowerShell ในโหมดซ่อนหน้าต่างหรือหลบเลี่ยง Execution Policy',
    });
  }

  if (indicators.registryKeys.length > 0) {
    attacks.push({
      id: 'T1547.001',
      tactic: 'Persistence',
      technique: 'Boot or Logon Autostart Execution: Registry Run Keys',
      description: 'พยายามแก้ไข Windows Registry Run Keys เพื่อให้มัลแวร์ทำงานอัตโนมัติทุกครั้งที่เปิดเครื่อง',
    });
  }

  if (indicators.dangerousApiCalls.some(a => ['VirtualAlloc', 'WriteProcessMemory', 'CreateRemoteThread'].includes(a))) {
    attacks.push({
      id: 'T1055',
      tactic: 'Privilege Escalation / Defense Evasion',
      technique: 'Process Injection',
      description: 'พบฟังก์ชัน Memory Allocation และ Process Injection เพื่อแทรกซึมเข้าสู่โปรเซสระบบที่ถูกต้อง',
    });
  }

  if (indicators.suspiciousStrings.some(s => s.includes('Shadow') || s.includes('Catalog'))) {
    attacks.push({
      id: 'T1490',
      tactic: 'Impact',
      technique: 'Inhibit System Recovery: VSS Deletion',
      description: 'พฤติกรรมเฉพาะของแรนซัมแวร์: ลบ Shadow Copies และแคตตาล็อกสำรองข้อมูลเพื่อป้องกันการกู้คืน',
    });
  }

  if (indicators.urlsOrIps.length > 0) {
    attacks.push({
      id: 'T1071.001',
      tactic: 'Command and Control',
      technique: 'Application Layer Protocol: Web Protocols',
      description: 'ตรวจพบการเชื่อมต่อเครือข่ายภายนอกหรือ URL เพื่อดาวน์โหลด Secondary Payload หรือส่งข้อมูลออก',
    });
  }

  return attacks;
}

/**
 * Generates recommended remediation guidance
 */
export function generateRemediation(severity: ThreatSeverity, family: string): string[] {
  if (severity === 'clean') {
    return [
      'ไฟล์นี้ผ่านเกณฑ์การตรวจสอบความปลอดภัย ไม่พบมัลแวร์หรือพฤติกรรมเสี่ยง',
      'ปลอดภัยสำหรับการเปิดและใช้งานตามปกติ',
      'หมั่นอัปเดตระบบปฏิบัติการและซอฟต์แวร์ป้องกันไวรัสเป็นประจำ',
    ];
  }

  if (severity === 'suspicious') {
    return [
      'แยกไฟล์ไว้ในโฟลเดอร์กักกัน (Quarantine) ชั่วคราว และไม่ควรเปิดทำงานด้วยสิทธิ์ Administrator',
      'ตรวจสอบที่มาของไฟล์และผู้ส่ง หากไม่แน่ใจให้ลบไฟล์ทันที',
      'สแกนไดรฟ์ที่ดาวน์โหลดไฟล์ด้วยเครื่องมือสแกนแบบเต็มระบบ (Full System Scan)',
    ];
  }

  return [
    `ตรวจพบภัยคุกคามระดับสูง (${family}) ให้กักกันหรือลบไฟล์นี้ทันที`,
    'ตัดการเชื่อมต่อเครือข่ายอินเทอร์เน็ตของเครื่องปลายทางเพื่อป้องกันการส่งข้อมูลออก (C2 Exfiltration)',
    'ตรวจสอบ Task Scheduler และ Registry Run Keys สำหรับสิ่งแปลกปลอมที่อาจถูกติดตั้งไว้',
    'เปลี่ยนรหัสผ่านของบัญชีสำคัญ (Email, VPN, Banking) ที่ล็อกอินไว้ในอุปกรณ์นี้',
  ];
}
