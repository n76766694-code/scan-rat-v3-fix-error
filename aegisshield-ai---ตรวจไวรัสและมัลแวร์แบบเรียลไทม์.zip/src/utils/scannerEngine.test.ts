import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateShannonEntropy,
  calculateBlockEntropy,
  detectMagicHeader,
  inspectStringsAndHeuristics,
  evaluateThreatScore,
  generateHashes,
  mapMitreAttacks,
  parseFileStructure,
  disassembleAndAnnotateLines,
  classifyVirusCategory,
} from './scannerEngine';

test('calculateShannonEntropy returns 0 for empty array', () => {
  const empty = new Uint8Array(0);
  assert.equal(calculateShannonEntropy(empty), 0);
});

test('calculateShannonEntropy returns 0 for identical bytes and near 8 for random bytes', () => {
  const zeroes = new Uint8Array(256).fill(65);
  assert.equal(calculateShannonEntropy(zeroes), 0);

  const allBytes = new Uint8Array(256);
  for (let i = 0; i < 256; i++) allBytes[i] = i;
  const entropy = calculateShannonEntropy(allBytes);
  assert.equal(entropy, 8.0);
});

test('detectMagicHeader identifies PE executable and disguised extension mismatch', () => {
  const peBytes = new Uint8Array([0x4D, 0x5A, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00]);
  const peNormal = detectMagicHeader(peBytes, 'program.exe');
  assert.equal(peNormal.isExecutable, true);
  assert.equal(peNormal.mismatchRisk, false);

  const peDisguised = detectMagicHeader(peBytes, 'invoice.pdf');
  assert.equal(peDisguised.isExecutable, true);
  assert.equal(peDisguised.mismatchRisk, true);
});

test('parseFileStructure decomposes PE executables and detects section risks', () => {
  const peBytes = new Uint8Array([0x4D, 0x5A, 0x00, 0x00]);
  const sampleContent = 'powershell.exe -ExecutionPolicy Bypass\nVirtualAlloc\nvssadmin delete shadows';
  const sections = parseFileStructure(peBytes, 'sample.exe', sampleContent);

  assert.ok(sections.length >= 4);
  assert.ok(sections.some(s => s.name.includes('.text')));
  assert.ok(sections.some(s => s.hasThreat === true));
});

test('disassembleAndAnnotateLines pinpoints malicious lines and provides explanations', () => {
  const sampleCode = `
Line 1: Normal comment
powershell.exe -ExecutionPolicy Bypass -WindowStyle Hidden
VirtualAlloc(0, 4096, MEM_COMMIT, PAGE_EXECUTE_READWRITE)
vssadmin delete shadows /all /quiet
Line 5: Safe print function
  `;

  const { lines, location } = disassembleAndAnnotateLines(sampleCode, 'test.bat');
  assert.ok(lines.length >= 5);
  assert.ok(location.lineNumbers.length >= 3, 'Should locate powershell, VirtualAlloc, and vssadmin lines');
  assert.ok(location.executionFlow.length >= 3);
  assert.ok(location.howItWorksTh.length > 20);

  const psLine = lines.find(l => l.threatTag?.includes('PowerShell'));
  assert.ok(psLine, 'Should tag powershell line');
  assert.ok(psLine?.explanation?.includes('PowerShell'));
});

test('classifyVirusCategory maps malware families accurately', () => {
  assert.equal(classifyVirusCategory('Trojan.Dropper', 'setup.exe', false), 'Trojan');
  assert.equal(classifyVirusCategory('Ransom.Lockbit', 'encryptor.exe', false), 'Ransomware');
  assert.equal(classifyVirusCategory('Macro.W97M', 'invoice.docm', false), 'Macro Malware');
  assert.equal(classifyVirusCategory('Infostealer.Python', 'stealer.py', false), 'Spyware / Infostealer');
  assert.equal(classifyVirusCategory('Clean / Verified', 'clean.pdf', true), 'Clean');
});
