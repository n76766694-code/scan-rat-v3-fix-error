export type ThreatSeverity = 'clean' | 'suspicious' | 'malicious' | 'critical';

export interface MitreAttackItem {
  id: string;
  tactic: string;
  technique: string;
  description: string;
}

export interface ExtractedIndicators {
  suspiciousStrings: string[];
  urlsOrIps: string[];
  registryKeys: string[];
  dangerousApiCalls: string[];
  networkActivityRisk: 'None' | 'Low' | 'Medium' | 'High';
}

export interface AIForensicAssessment {
  summaryTh: string;
  summaryEn: string;
  suspicionReasons: string[];
  confidenceScore: number;
  potentialDamage: string;
  quarantineRecommended: boolean;
  behavioralClassification: string;
}

export interface FileSection {
  name: string;
  size: number;
  entropy: number;
  description: string;
  hasThreat: boolean;
  offsetHex?: string;
}

export interface CodeLineAnnotation {
  lineNum: number;
  content: string;
  isMalicious: boolean;
  threatTag?: string;
  explanation?: string;
}

export interface MalwareLocationDetails {
  section: string;
  lineNumbers: number[];
  offsetHex: string;
  executionFlow: string[];
  payloadAnalysis: string;
  howItWorksTh: string;
}

export interface ScanReport {
  id: string;
  filename: string;
  fileSize: number;
  fileType: string;
  detectedMime: string;
  magicBytes: string;
  md5: string;
  sha256: string;
  entropyScore: number; // 0.00 to 8.00
  entropyVerdict: 'Low' | 'Moderate' | 'High (Packer/Crypto)';
  entropyBlocks: number[];
  severity: ThreatSeverity;
  threatScore: number; // 0 - 100
  malwareFamily: string;
  virusClassification: 'Clean' | 'Trojan' | 'Ransomware' | 'Spyware / Infostealer' | 'Macro Malware' | 'Steganography / WebShell' | 'EICAR Test' | 'Riskware / PUP';
  fileStructure: FileSection[];
  annotatedLines: CodeLineAnnotation[];
  malwareLocation?: MalwareLocationDetails;
  aiForensics: AIForensicAssessment;
  mitreAttacks: MitreAttackItem[];
  indicators: ExtractedIndicators;
  remediationSteps: string[];
  scanDurationMs: number;
  timestamp: string;
  quarantined: boolean;
  rawContentSnippet?: string;
}

export type ScanStage = 
  | 'idle'
  | 'reading_file'
  | 'hashing_signatures'
  | 'entropy_analysis'
  | 'string_disassembly'
  | 'ai_forensic_eval'
  | 'completed'
  | 'error';
