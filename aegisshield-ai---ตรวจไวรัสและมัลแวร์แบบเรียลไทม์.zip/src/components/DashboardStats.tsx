import React from 'react';
import { ShieldCheck, ShieldAlert, FileText, Zap, Cpu } from 'lucide-react';
import { ScanReport } from '../types/scanner';

interface DashboardStatsProps {
  reports: ScanReport[];
  lang: 'th' | 'en';
}

export const DashboardStats: React.FC<DashboardStatsProps> = ({ reports, lang }) => {
  const total = reports.length;
  const cleanCount = reports.filter(r => r.severity === 'clean').length;
  const threatsCount = reports.filter(r => r.severity === 'malicious' || r.severity === 'critical').length;
  const suspiciousCount = reports.filter(r => r.severity === 'suspicious').length;
  const cleanPercentage = total > 0 ? Math.round((cleanCount / total) * 100) : 100;
  
  const avgLatency = total > 0
    ? Math.round(reports.reduce((acc, r) => acc + (r.scanDurationMs || 320), 0) / total)
    : 280;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
      {/* Total Scanned */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4.5 relative overflow-hidden backdrop-blur-sm">
        <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full blur-2xl -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {lang === 'th' ? 'ไฟล์ที่สแกนทั้งหมด' : 'Total Files Scanned'}
          </span>
          <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <FileText className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono">
            {total}
          </span>
          <span className="text-xs text-slate-400">
            {lang === 'th' ? 'รายการ' : 'files'}
          </span>
        </div>
        <div className="mt-2 text-xs text-cyan-400 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
          <span>{lang === 'th' ? 'สแกนระดับไบต์เชิงลึก' : 'Deep-byte inspection'}</span>
        </div>
      </div>

      {/* Clean Files */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4.5 relative overflow-hidden backdrop-blur-sm">
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/5 rounded-full blur-2xl -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {lang === 'th' ? 'ไฟล์ปลอดภัย' : 'Verified Safe'}
          </span>
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <ShieldCheck className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono">
            {cleanCount}
          </span>
          <span className="text-xs text-emerald-500/90 font-medium">
            ({cleanPercentage}%)
          </span>
        </div>
        <div className="mt-2 text-xs text-slate-400">
          {lang === 'th' ? 'ไร้สิ่งเจือปน/ไวรัส' : 'Clean & uninfected'}
        </div>
      </div>

      {/* Threats Caught */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4.5 relative overflow-hidden backdrop-blur-sm">
        <div className="absolute top-0 right-0 w-24 h-24 bg-rose-500/5 rounded-full blur-2xl -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {lang === 'th' ? 'ตรวจพบมัลแวร์' : 'Threats Detected'}
          </span>
          <div className="p-2 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
            <ShieldAlert className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-extrabold text-rose-400 font-mono">
            {threatsCount}
          </span>
          {suspiciousCount > 0 && (
            <span className="text-xs text-amber-400 font-medium">
              (+{suspiciousCount} {lang === 'th' ? 'น่าสงสัย' : 'suspect'})
            </span>
          )}
        </div>
        <div className="mt-2 text-xs text-rose-400 flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-400 animate-ping"></span>
          <span>{lang === 'th' ? 'กักกัน/สกัดกั้นทันที' : 'Quarantine ready'}</span>
        </div>
      </div>

      {/* Latency / Speed */}
      <div className="bg-slate-900/70 border border-slate-800/80 rounded-2xl p-4.5 relative overflow-hidden backdrop-blur-sm">
        <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/5 rounded-full blur-2xl -mr-6 -mt-6"></div>
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            {lang === 'th' ? 'ความเร็ววิเคราะห์เฉลี่ย' : 'Avg Scan Latency'}
          </span>
          <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Zap className="w-4 h-4" />
          </div>
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-extrabold text-indigo-300 font-mono">
            {avgLatency}
          </span>
          <span className="text-xs text-slate-400 font-mono">ms</span>
        </div>
        <div className="mt-2 text-xs text-indigo-400 flex items-center gap-1">
          <Cpu className="w-3.5 h-3.5" />
          <span>{lang === 'th' ? 'AI วิเคราะห์แบบคู่ขนาน' : 'Real-time pipeline'}</span>
        </div>
      </div>
    </div>
  );
};
