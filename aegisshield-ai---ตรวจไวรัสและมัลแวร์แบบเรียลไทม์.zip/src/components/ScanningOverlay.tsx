import React, { useEffect, useState } from 'react';
import { Shield, Cpu, Binary, Search, Activity, CheckCircle2 } from 'lucide-react';

interface ScanningOverlayProps {
  filename: string;
  lang: 'th' | 'en';
}

const STAGES = [
  {
    titleTh: '1. ตรวจสอบ Header ไบต์ & ป้องกันการปลอมแปลงนามสกุล',
    titleEn: '1. Magic Bytes & Masquerading Header Verification',
    icon: Binary,
  },
  {
    titleTh: '2. คำนวณ Shannon Entropy & ตรวจจับการบีบอัด/พรางโค้ด',
    titleEn: '2. Shannon Entropy & Packer/Obfuscation Analysis',
    icon: Activity,
  },
  {
    titleTh: '3. สกัดสตริงต้องสงสัย, API Hooks & Registry Run Keys',
    titleEn: '3. Disassembly, Suspicious Strings & Dangerous APIs',
    icon: Search,
  },
  {
    titleTh: '4. Gemini 3.8 Flash วิเคราะห์เจตนาและพฤติกรรมเชิงลึก',
    titleEn: '4. Gemini 3.8 Flash Neural Cognitive Threat Reasoning',
    icon: Cpu,
  },
  {
    titleTh: '5. ทำแผนที่ MITRE ATT&CK Matrix & สรุปผลการประเมิน',
    titleEn: '5. MITRE ATT&CK Matrix Mapping & Report Synthesis',
    icon: Shield,
  },
];

export const ScanningOverlay: React.FC<ScanningOverlayProps> = ({ filename, lang }) => {
  const [currentStageIndex, setCurrentStageIndex] = useState(0);
  const [progress, setProgress] = useState(15);
  const [hexSnippet, setHexSnippet] = useState('4D 5A 90 00 03 00 00 00 04 00 00 00 FF FF');

  useEffect(() => {
    const stageTimer = setInterval(() => {
      setCurrentStageIndex((prev) => (prev < STAGES.length - 1 ? prev + 1 : prev));
    }, 600);

    const progressTimer = setInterval(() => {
      setProgress((prev) => (prev < 96 ? prev + Math.floor(Math.random() * 8) + 4 : prev));
    }, 200);

    const hexChars = '0123456789ABCDEF';
    const hexTimer = setInterval(() => {
      let randHex = '';
      for (let i = 0; i < 16; i++) {
        randHex += hexChars[Math.floor(Math.random() * 16)] + hexChars[Math.floor(Math.random() * 16)] + ' ';
      }
      setHexSnippet(randHex.trim());
    }, 150);

    return () => {
      clearInterval(stageTimer);
      clearInterval(progressTimer);
      clearInterval(hexTimer);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4">
      <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl shadow-cyan-500/20 relative overflow-hidden text-center">
        {/* Animated Cyber Grid Glow */}
        <div className="absolute inset-0 pointer-events-none cyber-grid-bg opacity-20"></div>
        <div className="absolute -top-24 -left-24 w-48 h-48 bg-cyan-500/20 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-blue-500/20 rounded-full blur-3xl"></div>

        {/* Central Pulsing Radar Icon */}
        <div className="relative mx-auto w-20 h-20 mb-6 flex items-center justify-center">
          <div className="absolute inset-0 rounded-full border-2 border-cyan-400/40 animate-ping opacity-75"></div>
          <div className="absolute inset-0 rounded-full border border-cyan-500/60 animate-spin"></div>
          <div className="w-16 h-16 rounded-full bg-slate-950 border border-cyan-400/80 flex items-center justify-center shadow-lg shadow-cyan-500/40">
            <Shield className="w-8 h-8 text-cyan-400 animate-pulse" />
          </div>
        </div>

        <h3 className="text-xl font-extrabold text-white">
          {lang === 'th' ? 'กำลังสแกนไฟล์แบบเรียลไทม์' : 'Real-Time Deep Inspection'}
        </h3>
        <p className="text-xs text-cyan-400 font-mono mt-1 truncate px-4">
          target: {filename}
        </p>

        {/* Progress Bar & Percentage */}
        <div className="mt-6 mb-2">
          <div className="flex justify-between text-xs font-mono text-slate-400 mb-1.5">
            <span>{lang === 'th' ? 'วิเคราะห์เชิงลึกทุกมิติ' : 'Neural Pipeline Status'}</span>
            <span className="text-cyan-400 font-bold">{Math.min(99, progress)}%</span>
          </div>
          <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
            <div
              className="bg-gradient-to-r from-cyan-500 via-blue-500 to-indigo-500 h-full rounded-full transition-all duration-300 shadow-md shadow-cyan-500/50"
              style={{ width: `${Math.min(99, progress)}%` }}
            ></div>
          </div>
        </div>

        {/* Simulated Hex Stream */}
        <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-2.5 text-center my-4 font-mono text-[11px] text-cyan-300/80 tracking-widest overflow-hidden">
          <span className="opacity-60 text-slate-500">RAW_BYTE_STREAM:</span> {hexSnippet}
        </div>

        {/* Step-by-Step Checklist */}
        <div className="text-left space-y-2 mt-5">
          {STAGES.map((stage, idx) => {
            const isDone = idx < currentStageIndex;
            const isCurrent = idx === currentStageIndex;
            const IconComponent = stage.icon;

            return (
              <div
                key={idx}
                className={`flex items-center gap-2.5 px-3 py-1.5 rounded-lg text-xs transition-all ${
                  isCurrent
                    ? 'bg-cyan-950/50 border border-cyan-500/40 text-cyan-300 font-medium'
                    : isDone
                    ? 'text-emerald-400/90'
                    : 'text-slate-500 opacity-60'
                }`}
              >
                {isDone ? (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                ) : isCurrent ? (
                  <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin shrink-0"></div>
                ) : (
                  <IconComponent className="w-4 h-4 text-slate-600 shrink-0" />
                )}
                <span className="truncate">
                  {lang === 'th' ? stage.titleTh : stage.titleEn}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
