import React, { useState, useRef } from 'react';
import {
  UploadCloud,
  FileCode,
  FileCheck2,
  FileWarning,
  Sparkles,
  Layers,
  ArrowRight,
  AlertTriangle,
  Code2,
  FileText,
  Binary,
} from 'lucide-react';
import { SAMPLE_FILES, SampleFileItem } from '../utils/sampleFiles';

interface FileUploaderProps {
  onScanFile: (fileData: {
    filename: string;
    content: string;
    isBase64: boolean;
    fileSize: number;
  }) => void;
  isScanning: boolean;
  lang: 'th' | 'en';
}

export const FileUploader: React.FC<FileUploaderProps> = ({
  onScanFile,
  isScanning,
  lang,
}) => {
  const [dragOver, setDragOver] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{
    name: string;
    size: number;
    type: string;
    content: string;
    isBase64: boolean;
  } | null>(null);

  const [inputMode, setInputMode] = useState<'upload' | 'paste'>('upload');
  const [pastedCode, setPastedCode] = useState('');
  const [pastedFilename, setPastedFilename] = useState('suspicious_script.ps1');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    readFile(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      readFile(file);
    }
  };

  const readFile = (file: File) => {
    const reader = new FileReader();
    // If small text-like file, read as text; otherwise as base64 or array buffer
    const isTextLike = /\.(txt|py|js|ts|html|php|bat|ps1|vbs|sh|json|xml|css|c|cpp|rs|go)$/i.test(file.name);

    if (isTextLike) {
      reader.onload = (e) => {
        const text = (e.target?.result as string) || '';
        setSelectedFile({
          name: file.name,
          size: file.size,
          type: file.type || 'text/plain',
          content: text,
          isBase64: false,
        });
      };
      reader.readAsText(file);
    } else {
      reader.onload = (e) => {
        const dataUrl = (e.target?.result as string) || '';
        const base64 = dataUrl.split(',')[1] || '';
        setSelectedFile({
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          content: base64,
          isBase64: true,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSelectSample = (sample: SampleFileItem) => {
    setSelectedFile({
      name: sample.name,
      size: sample.content.length,
      type: sample.category,
      content: sample.content,
      isBase64: false,
    });
  };

  const handleTriggerScan = () => {
    if (inputMode === 'paste') {
      if (!pastedCode.trim()) return;
      onScanFile({
        filename: pastedFilename || 'pasted_payload.ps1',
        content: pastedCode,
        isBase64: false,
        fileSize: new Blob([pastedCode]).size,
      });
      return;
    }

    if (selectedFile) {
      onScanFile({
        filename: selectedFile.name,
        content: selectedFile.content,
        isBase64: selectedFile.isBase64,
        fileSize: selectedFile.size,
      });
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-md mb-8 relative overflow-hidden shadow-2xl shadow-cyan-950/20">
      {/* Decorative cyber backdrop lights */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -mt-48"></div>
      <div className="absolute bottom-0 right-1/4 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none -mb-40"></div>

      {/* Mode selection tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-cyan-400" />
            {lang === 'th' ? 'อัปโหลดและสแกนไฟล์แบบเรียลไทม์' : 'Real-Time File AI Scanner'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {lang === 'th'
              ? 'รองรับไฟล์ทุกประเภท: .EXE, .PDF, .DOCX, .ZIP, .JS, .PY, .APK, ไบนารี และสคริปต์'
              : 'Supports all formats: .EXE, .PDF, .DOCX, .ZIP, .JS, .PY, .APK, binaries, and scripts'}
          </p>
        </div>

        <div className="flex items-center bg-slate-950/80 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            onClick={() => setInputMode('upload')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              inputMode === 'upload'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <UploadCloud className="w-3.5 h-3.5" />
            {lang === 'th' ? 'อัปโหลดไฟล์' : 'Upload File'}
          </button>
          <button
            onClick={() => setInputMode('paste')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              inputMode === 'paste'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            {lang === 'th' ? 'วางโค้ด/สคริปต์' : 'Paste Code'}
          </button>
        </div>
      </div>

      {inputMode === 'upload' ? (
        /* Upload Area */
        <div className="mt-6">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragOver(true);
            }}
            onDragLeave={() => setDragOver(false)}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`relative group cursor-pointer border-2 border-dashed rounded-2xl p-8 sm:p-12 text-center transition-all duration-300 ${
              dragOver
                ? 'border-cyan-400 bg-cyan-950/20 shadow-lg shadow-cyan-500/10'
                : selectedFile
                ? 'border-cyan-500/40 bg-slate-950/60'
                : 'border-slate-700 hover:border-cyan-500/60 bg-slate-950/40 hover:bg-slate-950/70'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              aria-label="Upload file for virus scan"
            />

            {/* Cyber animated scan line */}
            <div className="absolute inset-x-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent pointer-events-none animate-cyber-scan"></div>

            <div className="flex flex-col items-center justify-center">
              <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-4 group-hover:scale-105 transition-transform shadow-inner">
                {selectedFile ? (
                  <FileCheck2 className="w-8 h-8 text-cyan-300" />
                ) : (
                  <UploadCloud className="w-8 h-8" />
                )}
              </div>

              {selectedFile ? (
                <div>
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-500/30 text-cyan-300 text-xs font-mono mb-2">
                    <Binary className="w-3.5 h-3.5" />
                    <span>{selectedFile.name}</span>
                  </div>
                  <p className="text-sm text-slate-300 font-medium">
                    {lang === 'th' ? 'ขนาด:' : 'Size:'} {formatFileSize(selectedFile.size)} •{' '}
                    <span className="text-cyan-400">{lang === 'th' ? 'พร้อมสำหรับการสแกน' : 'Ready to inspect'}</span>
                  </p>
                  <p className="text-xs text-slate-500 mt-2">
                    {lang === 'th' ? 'คลิกที่นี่เพื่อเปลี่ยนไฟล์' : 'Click to select another file'}
                  </p>
                </div>
              ) : (
                <div>
                  <h3 className="text-base sm:text-lg font-semibold text-white">
                    {lang === 'th'
                      ? 'ลากไฟล์มาวางที่นี่ หรือคลิกเพื่อเลือกไฟล์'
                      : 'Drag & drop your file here, or click to browse'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-md mx-auto">
                    {lang === 'th'
                      ? 'ระบบจะทำการแฮช คำนวณเอนโทรปี แยกสตริงต้องสงสัย และใช้ Gemini 3.8 Flash ตรวจสอบอย่างละเอียด'
                      : 'Real-time multi-layer inspection with Shannon entropy, heuristic disassembly, and AI reasoning.'}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Code/Text Paste Area */
        <div className="mt-6 space-y-4">
          <div className="flex items-center gap-3">
            <label className="text-xs font-semibold text-slate-300">
              {lang === 'th' ? 'ตั้งชื่อไฟล์จำลอง:' : 'Mock Filename:'}
            </label>
            <input
              type="text"
              value={pastedFilename}
              onChange={(e) => setPastedFilename(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-cyan-300 font-mono w-64 focus:outline-none focus:border-cyan-500"
              placeholder="script.ps1 / code.py"
            />
          </div>

          <textarea
            value={pastedCode}
            onChange={(e) => setPastedCode(e.target.value)}
            rows={6}
            placeholder={
              lang === 'th'
                ? 'วางโค้ด PowerShell, Bash, Python, JavaScript, VBScript หรือเพย์โหลดที่ต้องการตรวจสอบที่นี่...'
                : 'Paste PowerShell, Bash, Python, JS, VBScript, or raw payload text here...'
            }
            className="w-full bg-slate-950 border border-slate-800 rounded-2xl p-4 text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
          ></textarea>
        </div>
      )}

      {/* Preset sample files for 1-click test */}
      <div className="mt-6 pt-6 border-t border-slate-800/80">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            {lang === 'th'
              ? 'หรือคลิกทดสอบด่วนด้วยไฟล์ตัวอย่าง (One-Click Presets):'
              : 'Or test instantly with verified sample presets:'}
          </span>
          <span className="text-[11px] text-slate-500 hidden sm:inline">
            {lang === 'th' ? 'ครอบคลุมทั้งไฟล์สะอาดและมัลแวร์จำลอง' : 'Safe for testing environment'}
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {SAMPLE_FILES.map((sample, idx) => {
            const isCritical = sample.expectedThreat === 'critical';
            const isMalicious = sample.expectedThreat === 'malicious';
            const isSuspicious = sample.expectedThreat === 'suspicious';
            const isClean = sample.expectedThreat === 'clean';

            let badgeColor = 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700 text-slate-300';
            if (isCritical) {
              badgeColor = 'bg-rose-950/40 hover:bg-rose-900/60 border-rose-800/50 text-rose-300';
            } else if (isMalicious) {
              badgeColor = 'bg-orange-950/40 hover:bg-orange-900/60 border-orange-800/50 text-orange-300';
            } else if (isSuspicious) {
              badgeColor = 'bg-amber-950/40 hover:bg-amber-900/60 border-amber-800/50 text-amber-300';
            } else if (isClean) {
              badgeColor = 'bg-emerald-950/40 hover:bg-emerald-900/60 border-emerald-800/50 text-emerald-300';
            }

            const isCurrentSelected = selectedFile?.name === sample.name;

            return (
              <button
                key={idx}
                type="button"
                onClick={() => handleSelectSample(sample)}
                className={`px-3 py-1.5 rounded-xl border text-xs flex items-center gap-1.5 transition-all text-left ${badgeColor} ${
                  isCurrentSelected ? 'ring-2 ring-cyan-400 scale-[1.02]' : ''
                }`}
                title={lang === 'th' ? sample.descriptionTh : sample.descriptionEn}
              >
                <span className="font-mono text-[11px] font-semibold">{sample.name}</span>
                <span className="text-[10px] opacity-75">({sample.tag})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Action Scan Button */}
      <div className="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-slate-400 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
          <span>
            {lang === 'th'
              ? 'ระบบจำลองการทำงานใน AI Sandbox ปลอดภัยต่อเครื่องผู้ใช้งาน 100%'
              : 'Isolated AI Sandbox analysis • Safe execution environment'}
          </span>
        </div>

        <button
          type="button"
          onClick={handleTriggerScan}
          disabled={
            isScanning ||
            (inputMode === 'upload' && !selectedFile) ||
            (inputMode === 'paste' && !pastedCode.trim())
          }
          className={`w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all shadow-lg ${
            isScanning ||
            (inputMode === 'upload' && !selectedFile) ||
            (inputMode === 'paste' && !pastedCode.trim())
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-[1.02] active:scale-[0.98]'
          }`}
        >
          {isScanning ? (
            <>
              <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></div>
              <span>{lang === 'th' ? 'กำลังสแกนแบบเรียลไทม์...' : 'Analyzing in Real-Time...'}</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4" />
              <span>{lang === 'th' ? 'เริ่มสแกนด้วย AI เจาะลึกทันที' : 'Start Real-Time AI Scan'}</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>
    </div>
  );
};
