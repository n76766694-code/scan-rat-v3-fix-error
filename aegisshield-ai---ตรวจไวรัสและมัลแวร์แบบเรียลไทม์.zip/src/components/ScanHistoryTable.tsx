import React, { useState } from 'react';
import {
  Search,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  AlertOctagon,
  Eye,
  Trash2,
  Lock,
} from 'lucide-react';
import { ScanReport } from '../types/scanner';

interface ScanHistoryTableProps {
  reports: ScanReport[];
  onSelectReport: (report: ScanReport) => void;
  onDeleteReport: (id: string) => void;
  lang: 'th' | 'en';
}

export const ScanHistoryTable: React.FC<ScanHistoryTableProps> = ({
  reports,
  onSelectReport,
  onDeleteReport,
  lang,
}) => {
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredReports = reports.filter((r) => {
    const matchesFilter =
      filterSeverity === 'all'
        ? true
        : filterSeverity === 'threats'
        ? r.severity === 'malicious' || r.severity === 'critical'
        : r.severity === filterSeverity;

    const query = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !query ||
      r.filename.toLowerCase().includes(query) ||
      r.malwareFamily.toLowerCase().includes(query) ||
      (r.virusClassification && r.virusClassification.toLowerCase().includes(query)) ||
      r.sha256.toLowerCase().includes(query) ||
      r.detectedMime.toLowerCase().includes(query);

    return matchesFilter && matchesSearch;
  });

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const formatDate = (iso: string) => {
    try {
      const d = new Date(iso);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch {
      return iso;
    }
  };

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-5 sm:p-7 backdrop-blur-md relative overflow-hidden shadow-xl">
      {/* Table Header and Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
            {lang === 'th' ? 'ประวัติการสแกน & รายการไฟล์' : 'Audit Log & Scanned Files'}
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            {lang === 'th'
              ? 'คลิกที่แถวเพื่อเข้าตรวจดูโค้ดภายใน ตำแหน่งไวรัส และถาม AI ได้ทันที'
              : 'Click any row to inspect internal code, virus location, and ask AI.'}
          </p>
        </div>

        {/* Filter and Search */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'th' ? 'ค้นหาชื่อไฟล์, ชนิดไวรัส...' : 'Search file, virus type...'}
              className="bg-slate-950 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 w-44 sm:w-56"
            />
          </div>

          {/* Filter pills */}
          <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
            <button
              onClick={() => setFilterSeverity('all')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterSeverity === 'all'
                  ? 'bg-slate-800 text-white font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lang === 'th' ? 'ทั้งหมด' : 'All'}
            </button>
            <button
              onClick={() => setFilterSeverity('clean')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterSeverity === 'clean'
                  ? 'bg-emerald-950 text-emerald-300 font-bold'
                  : 'text-slate-400 hover:text-emerald-300'
              }`}
            >
              {lang === 'th' ? 'ปลอดภัย' : 'Clean'}
            </button>
            <button
              onClick={() => setFilterSeverity('suspicious')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterSeverity === 'suspicious'
                  ? 'bg-amber-950 text-amber-300 font-bold'
                  : 'text-slate-400 hover:text-amber-300'
              }`}
            >
              {lang === 'th' ? 'น่าสงสัย' : 'Suspect'}
            </button>
            <button
              onClick={() => setFilterSeverity('threats')}
              className={`px-2.5 py-1 rounded-lg transition-all ${
                filterSeverity === 'threats'
                  ? 'bg-rose-950 text-rose-300 font-bold'
                  : 'text-slate-400 hover:text-rose-300'
              }`}
            >
              {lang === 'th' ? 'ภัยคุกคาม' : 'Threats'}
            </button>
          </div>
        </div>
      </div>

      {/* Table Content */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-800 text-slate-400 uppercase font-mono text-[10px] tracking-wider">
              <th className="pb-3 pl-2">{lang === 'th' ? 'ชื่อไฟล์' : 'File'}</th>
              <th className="pb-3">{lang === 'th' ? 'สถานะความปลอดภัย' : 'Verdict'}</th>
              <th className="pb-3">{lang === 'th' ? 'ชนิดไวรัส / การจำแนก' : 'Virus Classification'}</th>
              <th className="pb-3">{lang === 'th' ? 'Entropy' : 'Entropy'}</th>
              <th className="pb-3">{lang === 'th' ? 'เวลา' : 'Time'}</th>
              <th className="pb-3 text-right pr-2">{lang === 'th' ? 'การกระทำ' : 'Actions'}</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {filteredReports.length > 0 ? (
              filteredReports.map((item) => {
                const isClean = item.severity === 'clean';
                const isSuspicious = item.severity === 'suspicious';
                const isMalicious = item.severity === 'malicious';
                const isCritical = item.severity === 'critical';

                let badge = {
                  bg: 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40',
                  icon: ShieldCheck,
                  label: lang === 'th' ? 'ปลอดภัย' : 'Clean',
                };

                if (isSuspicious) {
                  badge = {
                    bg: 'bg-amber-950/60 text-amber-300 border-amber-500/40',
                    icon: AlertTriangle,
                    label: lang === 'th' ? 'น่าสงสัย' : 'Suspicious',
                  };
                } else if (isMalicious) {
                  badge = {
                    bg: 'bg-orange-950/60 text-orange-300 border-orange-500/40',
                    icon: ShieldAlert,
                    label: lang === 'th' ? 'อันตราย' : 'Malicious',
                  };
                } else if (isCritical) {
                  badge = {
                    bg: 'bg-rose-950/80 text-rose-300 border-rose-500/60',
                    icon: AlertOctagon,
                    label: lang === 'th' ? 'วิกฤต' : 'Critical',
                  };
                }

                const BadgeIcon = badge.icon;

                return (
                  <tr
                    key={item.id}
                    className="hover:bg-slate-800/40 transition-colors group cursor-pointer"
                    onClick={() => onSelectReport(item)}
                  >
                    {/* Filename and size */}
                    <td className="py-3.5 pl-2 max-w-xs">
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 shrink-0 font-mono text-[10px]">
                          {item.fileType}
                        </div>
                        <div className="min-w-0">
                          <span className="font-semibold text-white font-mono truncate block group-hover:text-cyan-300 transition-colors">
                            {item.filename}
                          </span>
                          <span className="text-[11px] text-slate-500">
                            {formatFileSize(item.fileSize)}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* Verdict */}
                    <td className="py-3.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`px-2.5 py-0.5 rounded-full border text-[11px] font-bold flex items-center gap-1 ${badge.bg}`}
                        >
                          <BadgeIcon className="w-3 h-3" />
                          <span>{badge.label}</span>
                        </span>
                        <span className="font-mono font-bold text-slate-300 text-xs">
                          {item.threatScore}/100
                        </span>
                      </div>
                    </td>

                    {/* Virus Classification Tag */}
                    <td className="py-3.5 text-xs text-slate-200">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          className={`px-2 py-0.5 rounded-md font-mono text-[11px] font-semibold border ${
                            isClean
                              ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                              : isCritical
                              ? 'bg-rose-950/50 border-rose-500/40 text-rose-300'
                              : 'bg-amber-950/40 border-amber-500/30 text-amber-300'
                          }`}
                        >
                          {item.virusClassification || (isClean ? 'Clean' : 'Trojan')}
                        </span>
                        <span className="text-slate-400 font-mono text-[11px] truncate max-w-[140px] block">
                          {item.malwareFamily}
                        </span>
                      </div>
                    </td>

                    {/* Entropy */}
                    <td className="py-3.5 font-mono text-xs">
                      <span
                        className={
                          item.entropyScore > 7.2 ? 'text-rose-400 font-bold' : 'text-slate-300'
                        }
                      >
                        {item.entropyScore}
                      </span>
                    </td>

                    {/* Time & Quarantine */}
                    <td className="py-3.5 text-slate-400 font-mono text-xs whitespace-nowrap">
                      {formatDate(item.timestamp)}
                      {item.quarantined && (
                        <span className="ml-2 inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-rose-950 text-rose-300 text-[10px] border border-rose-800">
                          <Lock className="w-2.5 h-2.5" />
                          Lock
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td className="py-3.5 text-right pr-2">
                      <div
                        className="flex items-center justify-end gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onSelectReport(item)}
                          title={lang === 'th' ? 'ตรวจดูโค้ดและถาม AI' : 'Inspect code and ask AI'}
                          aria-label={`Inspect ${item.filename}`}
                          className="px-2.5 py-1.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/80 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{lang === 'th' ? 'ตรวจดูโค้ด' : 'Inspect'}</span>
                        </button>
                        <button
                          onClick={() => onDeleteReport(item.id)}
                          title={lang === 'th' ? 'ลบรายการ' : 'Delete log'}
                          aria-label={`Delete record for ${item.filename}`}
                          className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={6} className="py-8 text-center text-slate-500 text-xs">
                  {lang === 'th'
                    ? 'ไม่พบรายการที่ตรงกับเงื่อนไขการค้นหา'
                    : 'No records match search filters.'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
