import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  AlertOctagon,
  AlertTriangle,
  X,
  Download,
  Printer,
  Copy,
  Check,
  Lock,
  Unlock,
  Terminal,
  Activity,
  FileCode,
  Layers,
  Info,
  Sparkles,
  Send,
  HelpCircle,
  FolderTree,
  Crosshair,
  Bug,
} from 'lucide-react';
import { ScanReport, CodeLineAnnotation } from '../types/scanner';

interface ScanResultModalProps {
  report: ScanReport;
  onClose: () => void;
  onToggleQuarantine: (id: string) => void;
  lang: 'th' | 'en';
}

export const ScanResultModal: React.FC<ScanResultModalProps> = ({
  report,
  onClose,
  onToggleQuarantine,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<
    'overview' | 'code' | 'structure' | 'ai' | 'iocs' | 'entropy' | 'mitre' | 'remediation'
  >('code'); // default to code tab so user immediately sees the code & virus location!

  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [selectedLine, setSelectedLine] = useState<CodeLineAnnotation | null>(
    report.annotatedLines?.find((l) => l.isMalicious) || report.annotatedLines?.[0] || null
  );

  const [aiExplanation, setAiExplanation] = useState<string>('');
  const [isExplaining, setIsExplaining] = useState<boolean>(false);
  const [customQuestion, setCustomQuestion] = useState<string>('');

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleDownloadJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(report, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `AegisShield_Report_${report.filename}_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const handlePrint = () => {
    window.print();
  };

  // Call server-side Gemini 3.8 Flash to explain the selected code line or answer question
  const handleAskAIAboutCode = async (line: CodeLineAnnotation, customQ?: string) => {
    setSelectedLine(line);
    setIsExplaining(true);
    setAiExplanation('');

    try {
      const response = await fetch('/api/explain-code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          filename: report.filename,
          codeLine: line.content,
          lineNum: line.lineNum,
          context: report.rawContentSnippet || report.annotatedLines.map((l) => l.content).join('\n'),
          userQuestion: customQ || '',
        }),
      });

      if (!response.ok) throw new Error('API failed');
      const data = await response.json();
      setAiExplanation(data.explanation || 'ไม่สามารถวิเคราะห์โค้ดได้');
    } catch {
      // Fallback
      if (line.isMalicious) {
        setAiExplanation(
          `**คำอธิบายโค้ดบรรทัด #${line.lineNum}:**\n\`${line.content}\`\n\n🚨 **ตรวจพบพฤติกรรมมัลแวร์ (${line.threatTag}):**\n${line.explanation}\n\nคำสั่งนี้มีเจตนาหลบเลี่ยงความปลอดภัยหรือเชื่อมต่อออกไปรับเพย์โหลดภายนอก แนะนำให้กักกันไฟล์ทันที`
        );
      } else {
        setAiExplanation(
          `**คำอธิบายโค้ดบรรทัด #${line.lineNum}:**\n\`${line.content}\`\n\n✅ **โค้ดส่วนนี้ปลอดภัย:**\n${line.explanation}`
        );
      }
    } finally {
      setIsExplaining(false);
    }
  };

  const isClean = report.severity === 'clean';
  const isSuspicious = report.severity === 'suspicious';
  const isMalicious = report.severity === 'malicious';
  const isCritical = report.severity === 'critical';

  let severityBadge = {
    bg: 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300',
    icon: ShieldCheck,
    titleTh: 'ปลอดภัย (VERIFIED CLEAN)',
    titleEn: 'CLEAN & SAFE',
  };

  if (isSuspicious) {
    severityBadge = {
      bg: 'bg-amber-950/60 border-amber-500/50 text-amber-300',
      icon: AlertTriangle,
      titleTh: 'น่าสงสัย (SUSPICIOUS)',
      titleEn: 'SUSPICIOUS FILE',
    };
  } else if (isMalicious) {
    severityBadge = {
      bg: 'bg-orange-950/60 border-orange-500/50 text-orange-300',
      icon: ShieldAlert,
      titleTh: 'อันตราย (MALICIOUS)',
      titleEn: 'MALICIOUS THREAT',
    };
  } else if (isCritical) {
    severityBadge = {
      bg: 'bg-rose-950/80 border-rose-500/60 text-rose-300',
      icon: AlertOctagon,
      titleTh: 'วิกฤต (CRITICAL MALWARE)',
      titleEn: 'CRITICAL THREAT',
    };
  }

  const BadgeIcon = severityBadge.icon;

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const maliciousLinesCount = report.annotatedLines?.filter((l) => l.isMalicious).length || 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-2 sm:p-4 md:p-6 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-700/80 rounded-3xl max-w-5xl w-full shadow-2xl shadow-cyan-950/30 overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="px-5 py-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5 flex-wrap">
            <span
              className={`px-3 py-1 rounded-full border text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 ${severityBadge.bg}`}
            >
              <BadgeIcon className="w-4 h-4" />
              <span>{lang === 'th' ? severityBadge.titleTh : severityBadge.titleEn}</span>
            </span>

            {/* Virus Category Tag */}
            <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-cyan-300 text-xs font-mono border border-slate-700">
              🏷️ {report.virusClassification || report.malwareFamily}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadJson}
              title={lang === 'th' ? 'ดาวน์โหลดรายงาน JSON' : 'Export JSON report'}
              aria-label="Export JSON report"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <Download className="w-4 h-4" />
            </button>
            <button
              onClick={handlePrint}
              title={lang === 'th' ? 'พิมพ์รายงาน' : 'Print report'}
              aria-label="Print report"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              aria-label="Close modal"
              className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950 hover:text-rose-400 text-slate-400 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Executive Threat Banner */}
        <div className="p-5 sm:p-6 bg-gradient-to-b from-slate-950/80 to-slate-900/60 border-b border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl sm:text-2xl font-black text-white font-mono truncate">
                {report.filename}
              </h2>
              {report.quarantined && (
                <span className="px-2.5 py-0.5 rounded-full bg-rose-900/80 text-rose-300 text-xs font-semibold border border-rose-500/40 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  {lang === 'th' ? 'ถูกกักกันแล้ว' : 'Quarantined'}
                </span>
              )}
            </div>

            <p className="text-sm font-semibold text-cyan-400 font-mono">
              {report.malwareFamily}
            </p>

            <p className="text-xs text-slate-400">
              {lang === 'th' ? 'ขนาด:' : 'Size:'} {formatFileSize(report.fileSize)} •{' '}
              {lang === 'th' ? 'ประเภทตรวจพบ:' : 'MIME:'}{' '}
              <span className="font-mono text-slate-300">{report.detectedMime}</span> •{' '}
              {lang === 'th' ? 'เวลาสแกน:' : 'Speed:'}{' '}
              <span className="font-mono text-slate-300">{report.scanDurationMs} ms</span>
            </p>
          </div>

          {/* Threat Gauge Meter */}
          <div className="flex items-center gap-4 bg-slate-950/90 border border-slate-800 px-5 py-3 rounded-2xl shrink-0 self-stretch md:self-auto justify-between md:justify-start">
            <div className="text-right">
              <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                {lang === 'th' ? 'ระดับความเสี่ยง' : 'Threat Score'}
              </div>
              <div className="text-xs text-slate-500">
                {lang === 'th' ? 'ความมั่นใจ AI:' : 'AI Confidence:'}{' '}
                <strong className="text-slate-300 font-mono">
                  {report.aiForensics.confidenceScore}%
                </strong>
              </div>
            </div>

            <div className="relative flex items-center justify-center">
              <div
                className={`w-14 h-14 rounded-full border-4 flex items-center justify-center font-mono font-black text-lg ${
                  report.threatScore >= 80
                    ? 'border-rose-500 text-rose-400 bg-rose-950/30'
                    : report.threatScore >= 50
                    ? 'border-orange-500 text-orange-400 bg-orange-950/30'
                    : report.threatScore >= 25
                    ? 'border-amber-500 text-amber-400 bg-amber-950/30'
                    : 'border-emerald-500 text-emerald-400 bg-emerald-950/30'
                }`}
              >
                {report.threatScore}
              </div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-800 bg-slate-950/50 px-4 sm:px-6 gap-1 overflow-x-auto text-xs font-semibold">
          {/* TAB: CODE INSPECTOR & VIRUS LOCATION */}
          <button
            onClick={() => setActiveTab('code')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'code'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5 text-cyan-400" />
            <span>{lang === 'th' ? '1. ตรวจดูโค้ด & ตำแหน่งไวรัส' : '1. Code & Threat Locator'}</span>
            {maliciousLinesCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-rose-500/30 text-rose-300 text-[10px] font-mono font-bold">
                {maliciousLinesCount}
              </span>
            )}
          </button>

          {/* TAB: STRUCTURE */}
          <button
            onClick={() => setActiveTab('structure')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'structure'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <FolderTree className="w-3.5 h-3.5 text-indigo-400" />
            <span>{lang === 'th' ? '2. โครงสร้างภายในไฟล์' : '2. File Anatomy'}</span>
          </button>

          {/* TAB: OVERVIEW */}
          <button
            onClick={() => setActiveTab('overview')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'overview'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Info className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? '3. บทสรุป & แฮช' : '3. Summary'}</span>
          </button>

          {/* TAB: AI FORENSICS */}
          <button
            onClick={() => setActiveTab('ai')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'ai'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>{lang === 'th' ? '4. วิเคราะห์ AI เชิงลึก' : '4. AI Forensics'}</span>
          </button>

          {/* TAB: IOCS */}
          <button
            onClick={() => setActiveTab('iocs')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'iocs'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bug className="w-3.5 h-3.5" />
            <span>IOCs ({report.indicators.suspiciousStrings.length + report.indicators.dangerousApiCalls.length})</span>
          </button>

          {/* TAB: MITRE */}
          <button
            onClick={() => setActiveTab('mitre')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'mitre'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            MITRE ({report.mitreAttacks.length})
          </button>

          {/* TAB: REMEDIATION */}
          <button
            onClick={() => setActiveTab('remediation')}
            className={`py-3 px-3.5 border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === 'remediation'
                ? 'border-cyan-400 text-cyan-300 bg-cyan-950/20'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            {lang === 'th' ? 'วิธีแก้ไข' : 'Remediation'}
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB: CODE INSPECTOR & THREAT LOCATOR (INTERACTIVE DISASSEMBLY & AI EXPLAINER) */}
          {activeTab === 'code' && (
            <div className="space-y-6">
              {/* Threat Location & Mechanics Banner */}
              {report.malwareLocation && report.malwareLocation.lineNumbers.length > 0 ? (
                <div className="bg-rose-950/30 border border-rose-800/60 rounded-2xl p-4 sm:p-5 space-y-3">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <div className="flex items-center gap-2 text-rose-300 font-bold text-sm">
                      <Crosshair className="w-4 h-4 text-rose-400 animate-pulse" />
                      <span>
                        {lang === 'th' ? 'ระบุตำแหน่งไวรัสในไฟล์:' : 'Malware Location Detected:'}
                      </span>
                      <span className="font-mono bg-rose-950 px-2.5 py-0.5 rounded border border-rose-700 text-rose-200 text-xs">
                        {report.malwareLocation.section}
                      </span>
                    </div>
                    <span className="text-xs font-mono text-rose-300 bg-rose-900/60 px-2 py-0.5 rounded">
                      Offset: {report.malwareLocation.offsetHex} • พบใน {report.malwareLocation.lineNumbers.length} บรรทัด
                    </span>
                  </div>

                  {/* How it works explanation */}
                  <div className="bg-slate-950/70 p-3 rounded-xl border border-rose-900/40 text-xs text-rose-200/90 leading-relaxed">
                    <span className="font-bold text-rose-400 mr-1.5">
                      {lang === 'th' ? '⚙️ กลไกการทำงานของมัลแวร์นี้:' : '⚙️ How this threat executes:'}
                    </span>
                    {report.malwareLocation.howItWorksTh}
                  </div>

                  {/* Execution Flow Steps */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block">
                      {lang === 'th' ? 'ลำดับการทำงาน (Execution Flow):' : 'Execution Flow Steps:'}
                    </span>
                    {report.malwareLocation.executionFlow.map((step, sIdx) => (
                      <div
                        key={sIdx}
                        className="text-xs font-mono text-slate-300 bg-slate-950/50 px-3 py-1.5 rounded-lg flex items-center gap-2 border border-slate-800/80"
                      >
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-400"></span>
                        <span>{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="bg-emerald-950/20 border border-emerald-800/40 rounded-2xl p-4 flex items-center gap-3 text-xs text-emerald-300">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-bold block">
                      {lang === 'th' ? 'ไม่พบโค้ดอันตรายในไฟล์นี้' : 'No malicious code detected'}
                    </span>
                    <span className="text-slate-400">
                      {lang === 'th'
                        ? 'ทุกบรรทัดคำสั่งและการทำงานเป็นไปตามมาตรฐานความปลอดภัย'
                        : 'All examined code blocks and instructions comply with safe standard operations.'}
                    </span>
                  </div>
                </div>
              )}

              {/* Code Disassembler with Inline AI Explain Buttons */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                {/* Code Viewer Panel (7 cols on lg) */}
                <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-2xl p-3 sm:p-4 font-mono text-xs overflow-hidden flex flex-col">
                  <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800 text-slate-400 text-[11px]">
                    <span className="flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{report.filename} (Line-by-Line Disassembly)</span>
                    </span>
                    <span className="text-slate-500">
                      คลิกปุ่ม 🧠 เพื่อให้ AI อธิบาย
                    </span>
                  </div>

                  <div className="overflow-y-auto max-h-[380px] space-y-1 pr-1 font-mono text-xs">
                    {report.annotatedLines?.length > 0 ? (
                      report.annotatedLines.map((line) => {
                        const isSelected = selectedLine?.lineNum === line.lineNum;
                        return (
                          <div
                            key={line.lineNum}
                            onClick={() => setSelectedLine(line)}
                            className={`group flex items-start gap-2 px-2 py-1.5 rounded-lg transition-colors cursor-pointer ${
                              line.isMalicious
                                ? 'bg-rose-950/40 border border-rose-800/50 hover:bg-rose-900/50'
                                : isSelected
                                ? 'bg-slate-800 border border-cyan-500/40'
                                : 'hover:bg-slate-900 border border-transparent'
                            }`}
                          >
                            <span className="text-slate-600 select-none w-8 text-right shrink-0">
                              {line.lineNum}
                            </span>

                            <div className="flex-1 min-w-0">
                              <span
                                className={`break-all ${
                                  line.isMalicious ? 'text-rose-300 font-bold' : 'text-slate-300'
                                }`}
                              >
                                {line.content}
                              </span>

                              {line.threatTag && (
                                <div className="text-[10px] text-rose-400 font-sans mt-0.5 flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3" />
                                  <span>{line.threatTag}</span>
                                </div>
                              )}
                            </div>

                            {/* Ask AI button on line */}
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAskAIAboutCode(line);
                              }}
                              title="ให้ AI อธิบายว่าบรรทัดนี้คืออะไรและทำอะไร"
                              className="opacity-80 group-hover:opacity-100 px-2 py-0.5 rounded bg-cyan-950 hover:bg-cyan-900 text-cyan-300 text-[10px] border border-cyan-500/40 flex items-center gap-1 shrink-0 transition-opacity"
                            >
                              <Sparkles className="w-3 h-3 text-cyan-400" />
                              <span className="hidden sm:inline">ถาม AI</span>
                            </button>
                          </div>
                        );
                      })
                    ) : (
                      <div className="p-4 text-slate-500 text-center">ไม่มีข้อมูลโค้ด</div>
                    )}
                  </div>
                </div>

                {/* AI Assistant Explanation Drawer (5 cols on lg) */}
                <div className="lg:col-span-5 bg-slate-950/90 border border-cyan-500/30 rounded-2xl p-4 flex flex-col justify-between shadow-lg shadow-cyan-950/20">
                  <div>
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-800">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-cyan-400" />
                        <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                          ผู้ช่วย AI วิเคราะห์โค้ด (AI Explainer)
                        </h4>
                      </div>
                      <span className="text-[10px] text-cyan-400 font-mono bg-cyan-950 px-2 py-0.5 rounded border border-cyan-800">
                        Gemini 3.8 Flash
                      </span>
                    </div>

                    {selectedLine ? (
                      <div className="space-y-3">
                        <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-xs font-mono">
                          <span className="text-slate-500 block text-[10px]">
                            บรรทัดที่เลือก (#{selectedLine.lineNum}):
                          </span>
                          <span
                            className={`block truncate ${
                              selectedLine.isMalicious ? 'text-rose-300' : 'text-cyan-300'
                            }`}
                          >
                            {selectedLine.content}
                          </span>
                        </div>

                        {/* Explanation output */}
                        <div className="bg-slate-900/60 p-3.5 rounded-xl border border-slate-800/80 min-h-[160px] max-h-[220px] overflow-y-auto text-xs text-slate-200 leading-relaxed font-sans">
                          {isExplaining ? (
                            <div className="flex flex-col items-center justify-center py-8 text-cyan-400">
                              <div className="w-6 h-6 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mb-2"></div>
                              <span>AI กำลังวิเคราะห์โค้ดเชิงลึก...</span>
                            </div>
                          ) : aiExplanation ? (
                            <div className="whitespace-pre-line">{aiExplanation}</div>
                          ) : (
                            <div>
                              <p className="text-slate-400 mb-2">
                                💡 <strong>คำอธิบายเบื้องต้น:</strong>
                              </p>
                              <p className="text-slate-300">{selectedLine.explanation}</p>
                              <p className="text-[11px] text-slate-500 mt-3">
                                กดปุ่มด้านล่างเพื่อให้ Gemini 3.8 Flash วิเคราะห์และอธิบายเพิ่มเติม
                              </p>
                            </div>
                          )}
                        </div>

                        {/* Quick explain trigger if not yet analyzed */}
                        {!aiExplanation && !isExplaining && (
                          <button
                            onClick={() => handleAskAIAboutCode(selectedLine)}
                            className="w-full py-2 px-3 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                          >
                            <Sparkles className="w-3.5 h-3.5" />
                            <span>ให้ AI เจาะลึกบรรทัดนี้ทันที</span>
                          </button>
                        )}
                      </div>
                    ) : (
                      <div className="text-center py-12 text-slate-500 text-xs">
                        คลิกที่บรรทัดโค้ดในหน้าต่างซ้ายมือเพื่อตรวจสอบ
                      </div>
                    )}
                  </div>

                  {/* Ask custom question to AI */}
                  <div className="mt-4 pt-3 border-t border-slate-800">
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (customQuestion.trim() && selectedLine) {
                          handleAskAIAboutCode(selectedLine, customQuestion.trim());
                        }
                      }}
                      className="flex items-center gap-2"
                    >
                      <input
                        type="text"
                        value={customQuestion}
                        onChange={(e) => setCustomQuestion(e.target.value)}
                        placeholder="ถาม AI เกี่ยวกับโค้ดนี้..."
                        className="flex-1 bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                      />
                      <button
                        type="submit"
                        disabled={isExplaining || !customQuestion.trim() || !selectedLine}
                        className="p-2 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 disabled:opacity-50 transition-colors"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: FILE STRUCTURE & ANATOMY */}
          {activeTab === 'structure' && (
            <div className="space-y-6">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <FolderTree className="w-4 h-4 text-cyan-400" />
                    {lang === 'th'
                      ? 'โครงสร้างสถาปัตยกรรมภายในไฟล์ (Internal File Anatomy)'
                      : 'File Anatomy & Internal Section Layout'}
                  </span>
                  <span className="text-xs font-mono text-cyan-400">
                    {report.fileStructure?.length || 0} Sections Parsed
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-4">
                  {report.fileStructure?.map((sec, idx) => (
                    <div
                      key={idx}
                      className={`p-4 rounded-xl border transition-all ${
                        sec.hasThreat
                          ? 'bg-rose-950/30 border-rose-800/60 shadow-md shadow-rose-950/30'
                          : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span
                          className={`font-mono text-xs font-bold ${
                            sec.hasThreat ? 'text-rose-300' : 'text-cyan-300'
                          }`}
                        >
                          {sec.name}
                        </span>
                        {sec.hasThreat ? (
                          <span className="px-2 py-0.5 rounded bg-rose-900/80 text-rose-300 text-[10px] font-bold">
                            พบภัยคุกคาม
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold">
                            ปลอดภัย
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-300 leading-relaxed mb-3">
                        {sec.description}
                      </p>

                      <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/60">
                        <span>Offset: {sec.offsetHex || 'N/A'}</span>
                        <span>Entropy: {sec.entropy}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB: OVERVIEW & EXECUTIVE SUMMARY */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Executive Summary Box */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  {lang === 'th' ? 'บทสรุปผู้บริหาร (Executive Summary)' : 'Executive Summary'}
                </h3>
                <p className="text-sm text-slate-200 leading-relaxed">
                  {lang === 'th' ? report.aiForensics.summaryTh : report.aiForensics.summaryEn}
                </p>
              </div>

              {/* Cryptographic Hashes & Fingerprints */}
              <div className="space-y-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  {lang === 'th'
                    ? 'ลายนิ้วมือดิจิทัล & แฮชของไฟล์ (Cryptographic Fingerprints)'
                    : 'File Fingerprints & Hashes'}
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs font-mono">
                  {/* SHA-256 */}
                  <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <span className="text-[10px] text-slate-500 block">SHA-256</span>
                      <span className="text-cyan-300 truncate block text-[11px]">
                        {report.sha256}
                      </span>
                    </div>
                    <button
                      onClick={() => handleCopy(report.sha256, 'sha256')}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0"
                    >
                      {copiedField === 'sha256' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* MD5 */}
                  <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <span className="text-[10px] text-slate-500 block">MD5</span>
                      <span className="text-cyan-300 truncate block text-[11px]">
                        {report.md5}
                      </span>
                    </div>
                    <button
                      onClick={() => handleCopy(report.md5, 'md5')}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 shrink-0"
                    >
                      {copiedField === 'md5' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* Magic Bytes */}
                  <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <span className="text-[10px] text-slate-500 block">
                        Magic Bytes Header (Hex)
                      </span>
                      <span className="text-indigo-300 truncate block text-[11px]">
                        {report.magicBytes}
                      </span>
                    </div>
                  </div>

                  {/* Shannon Entropy */}
                  <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 flex items-center justify-between">
                    <div className="min-w-0 pr-2">
                      <span className="text-[10px] text-slate-500 block">
                        Shannon Entropy (0.0 - 8.0)
                      </span>
                      <span
                        className={`text-[11px] font-bold ${
                          report.entropyScore > 7.2 ? 'text-rose-400' : 'text-emerald-400'
                        }`}
                      >
                        {report.entropyScore} ({report.entropyVerdict})
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: AI FORENSICS */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-cyan-950/40 via-slate-950/60 to-indigo-950/40 border border-cyan-500/30 rounded-2xl p-5">
                <div className="flex items-center gap-2 mb-2 text-cyan-400 text-xs font-bold uppercase tracking-wider">
                  <Terminal className="w-4 h-4" />
                  <span>
                    {lang === 'th'
                      ? 'การประเมินจาก Gemini 3.8 Flash Neural Engine'
                      : 'Gemini 3.8 Flash Neural Assessment'}
                  </span>
                </div>
                <p className="text-sm text-slate-100 leading-relaxed font-sans">
                  {report.aiForensics.summaryTh}
                </p>
                <div className="mt-3 pt-3 border-t border-slate-800 text-xs text-slate-400 italic">
                  "{report.aiForensics.summaryEn}"
                </div>
              </div>

              {/* Suspicion Reasons List */}
              <div className="space-y-3">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  {lang === 'th'
                    ? 'ข้อบ่งชี้และจุดที่ AI ให้ความสำคัญ (Key Inspection Observations)'
                    : 'Key Forensic Observations'}
                </h4>
                <div className="space-y-2">
                  {report.aiForensics.suspicionReasons.map((reason, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 bg-slate-950/60 border border-slate-800 p-3 rounded-xl text-xs text-slate-300"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 shrink-0"></span>
                      <span>{reason}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Potential Damage */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4">
                <div className="text-xs font-semibold text-rose-400 uppercase tracking-wider mb-1 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {lang === 'th'
                    ? 'ความเสียหายและผลกระทบที่อาจเกิดขึ้น (Potential Impact)'
                    : 'Potential System Impact'}
                </div>
                <p className="text-xs text-slate-300">{report.aiForensics.potentialDamage}</p>
              </div>
            </div>
          )}

          {/* TAB: IOCS */}
          {activeTab === 'iocs' && (
            <div className="space-y-6">
              {/* Suspicious Strings */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    {lang === 'th'
                      ? 'คำสั่ง/สตริงต้องสงสัยที่ตรวจพบ (Suspicious Commands & Disassembly)'
                      : 'Suspicious String Indicators'}
                  </span>
                  <span className="text-xs font-mono text-cyan-400">
                    {report.indicators.suspiciousStrings.length} found
                  </span>
                </div>
                {report.indicators.suspiciousStrings.length > 0 ? (
                  <div className="space-y-1.5">
                    {report.indicators.suspiciousStrings.map((str, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950/90 border border-rose-900/40 rounded-xl px-3.5 py-2 text-xs font-mono text-rose-300 flex items-center gap-2"
                      >
                        <span className="text-rose-500 font-bold">!</span>
                        <span>{str}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 text-xs text-slate-500 italic">
                    {lang === 'th'
                      ? 'ไม่พบสตริงหรือคำสั่งอันตรายในไฟล์นี้'
                      : 'No suspicious command strings detected.'}
                  </div>
                )}
              </div>

              {/* Dangerous APIs */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    {lang === 'th'
                      ? 'Windows APIs ที่มีความเสี่ยง (Process Injection / Memory Allocation)'
                      : 'Dangerous Windows APIs'}
                  </span>
                  <span className="text-xs font-mono text-indigo-400">
                    {report.indicators.dangerousApiCalls.length} found
                  </span>
                </div>
                {report.indicators.dangerousApiCalls.length > 0 ? (
                  <div className="flex flex-wrap gap-2">
                    {report.indicators.dangerousApiCalls.map((api, idx) => (
                      <span
                        key={idx}
                        className="px-2.5 py-1 rounded-lg bg-indigo-950/50 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-semibold"
                      >
                        {api}()
                      </span>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-500 italic">
                    {lang === 'th'
                      ? 'ไม่พบการเรียกใช้งาน Windows API อันตราย'
                      : 'No hazardous system APIs invoked.'}
                  </div>
                )}
              </div>

              {/* URLs and IPs */}
              <div className="space-y-2">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  {lang === 'th'
                    ? 'ที่อยู่เครือข่ายภายนอก / C2 Server (Network Indicators)'
                    : 'Network Indicators & C2 Endpoints'}
                </span>
                {report.indicators.urlsOrIps.length > 0 ? (
                  <div className="space-y-1.5 font-mono text-xs">
                    {report.indicators.urlsOrIps.map((addr, idx) => (
                      <div
                        key={idx}
                        className="bg-slate-950/80 border border-slate-800 rounded-xl p-2.5 text-cyan-300 flex items-center justify-between"
                      >
                        <span className="truncate pr-2">{addr}</span>
                        <span className="text-[10px] text-slate-500 uppercase">
                          Remote Endpoint
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 text-xs text-slate-500 italic">
                    {lang === 'th'
                      ? 'ไม่พบ IP หรือโดเมนแปลกปลอม'
                      : 'No external network endpoints extracted.'}
                  </div>
                )}
              </div>

              {/* Registry Persistence */}
              {report.indicators.registryKeys.length > 0 && (
                <div className="space-y-2">
                  <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    {lang === 'th'
                      ? 'การพยายามฝังตัวใน Registry (Persistence Keys)'
                      : 'Registry Persistence References'}
                  </span>
                  <div className="space-y-1.5 font-mono text-xs">
                    {report.indicators.registryKeys.map((reg, idx) => (
                      <div
                        key={idx}
                        className="bg-rose-950/20 border border-rose-800/40 rounded-xl p-2.5 text-rose-300"
                      >
                        {reg}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB: MITRE */}
          {activeTab === 'mitre' && (
            <div className="space-y-4">
              <div className="text-xs text-slate-400 mb-2">
                {lang === 'th'
                  ? 'แมปพฤติกรรมกับมาตรฐาน MITRE ATT&CK เพื่อความเข้าใจระดับสากล:'
                  : 'Behavioral tactics correlated with the MITRE ATT&CK framework:'}
              </div>

              {report.mitreAttacks.length > 0 ? (
                <div className="space-y-3">
                  {report.mitreAttacks.map((item, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono text-xs font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-500/30">
                          {item.id}
                        </span>
                        <span className="text-xs font-medium text-slate-400">{item.tactic}</span>
                      </div>
                      <h4 className="text-sm font-semibold text-white">{item.technique}</h4>
                      <p className="text-xs text-slate-300">{item.description}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-6 text-center text-xs text-slate-400">
                  <ShieldCheck className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                  {lang === 'th'
                    ? 'ไม่พบพฤติกรรมที่เข้าข่ายยุทธวิธีของมัลแวร์ในกรอบ MITRE ATT&CK'
                    : 'No malicious tactics matched under MITRE ATT&CK.'}
                </div>
              )}
            </div>
          )}

          {/* TAB: REMEDIATION */}
          {activeTab === 'remediation' && (
            <div className="space-y-4">
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 space-y-3">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  {lang === 'th'
                    ? 'คำแนะนำและขั้นตอนการปฏิบัติการรักษาความปลอดภัย'
                    : 'Actionable Security Recommendations'}
                </h3>
                <div className="space-y-2.5">
                  {report.remediationSteps.map((step, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-3 bg-slate-900/60 border border-slate-800/80 p-3 rounded-xl text-xs text-slate-200"
                    >
                      <span className="flex items-center justify-center w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold shrink-0 text-[11px]">
                        {idx + 1}
                      </span>
                      <span className="leading-relaxed">{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Bottom Actions */}
        <div className="px-5 py-3.5 border-t border-slate-800 bg-slate-950/80 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => onToggleQuarantine(report.id)}
              className={`w-full sm:w-auto px-4 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                report.quarantined
                  ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-900'
                  : 'bg-rose-950 border border-rose-500/40 text-rose-300 hover:bg-rose-900'
              }`}
            >
              {report.quarantined ? (
                <>
                  <Unlock className="w-3.5 h-3.5" />
                  <span>{lang === 'th' ? 'ปลดการกักกันไฟล์' : 'Un-quarantine'}</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5" />
                  <span>{lang === 'th' ? 'กักกันไฟล์ทันที (Quarantine)' : 'Quarantine File'}</span>
                </>
              )}
            </button>
          </div>

          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              onClick={handleDownloadJson}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{lang === 'th' ? 'ดาวน์โหลดรายงาน JSON' : 'Export JSON'}</span>
            </button>

            <button
              onClick={onClose}
              className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
            >
              {lang === 'th' ? 'เสร็จสิ้น / ปิดหน้าต่าง' : 'Done / Close'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
