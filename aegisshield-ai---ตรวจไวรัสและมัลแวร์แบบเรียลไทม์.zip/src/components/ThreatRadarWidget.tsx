import React from 'react';
import { ShieldCheck, ShieldAlert, Bug, FileCheck, Layers, AlertOctagon, Lock } from 'lucide-react';
import { ScanReport } from '../types/scanner';

interface ThreatRadarWidgetProps {
  reports: ScanReport[];
  lang: 'th' | 'en';
}

export const ThreatRadarWidget: React.FC<ThreatRadarWidgetProps> = ({ reports, lang }) => {
  // Aggregate virus classifications
  const safeCount = reports.filter((r) => r.severity === 'clean').length;
  const trojanCount = reports.filter((r) => r.virusClassification === 'Trojan' || r.malwareFamily.toLowerCase().includes('trojan')).length;
  const ransomwareCount = reports.filter((r) => r.virusClassification === 'Ransomware' || r.malwareFamily.toLowerCase().includes('ransom')).length;
  const spywareCount = reports.filter((r) => r.virusClassification === 'Spyware / Infostealer' || r.malwareFamily.toLowerCase().includes('stealer')).length;
  const macroCount = reports.filter((r) => r.virusClassification === 'Macro Malware' || r.malwareFamily.toLowerCase().includes('macro')).length;
  const stegoCount = reports.filter((r) => r.virusClassification === 'Steganography / WebShell' || r.malwareFamily.toLowerCase().includes('stego')).length;
  const eicarCount = reports.filter((r) => r.virusClassification === 'EICAR Test' || r.malwareFamily.toLowerCase().includes('eicar')).length;

  const virusCategories = [
    {
      typeTh: 'ไฟล์ปลอดภัย (Verified Safe)',
      typeEn: 'Safe / Clean Files',
      count: safeCount,
      color: 'bg-emerald-500',
      badge: 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40',
      icon: ShieldCheck,
    },
    {
      typeTh: 'โทรจัน (Trojan / Dropper)',
      typeEn: 'Trojan Droppers',
      count: trojanCount,
      color: 'bg-rose-500',
      badge: 'bg-rose-950/60 text-rose-300 border-rose-500/40',
      icon: AlertOctagon,
    },
    {
      typeTh: 'แรนซัมแวร์ (Ransomware)',
      typeEn: 'Ransomware Payloads',
      count: ransomwareCount,
      color: 'bg-red-600',
      badge: 'bg-red-950/60 text-red-300 border-red-500/40',
      icon: Lock,
    },
    {
      typeTh: 'สปายแวร์ / ขโมยรหัส (Infostealer)',
      typeEn: 'Infostealer & Spyware',
      count: spywareCount,
      color: 'bg-orange-500',
      badge: 'bg-orange-950/60 text-orange-300 border-orange-500/40',
      icon: Bug,
    },
    {
      typeTh: 'มัลแวร์มาโคร (Weaponized Macro)',
      typeEn: 'Weaponized Macros',
      count: macroCount,
      color: 'bg-amber-500',
      badge: 'bg-amber-950/60 text-amber-300 border-amber-500/40',
      icon: Layers,
    },
    {
      typeTh: 'การพรางตัว (Stego / WebShell)',
      typeEn: 'Steganography / WebShell',
      count: stegoCount,
      color: 'bg-indigo-500',
      badge: 'bg-indigo-950/60 text-indigo-300 border-indigo-500/40',
      icon: ShieldAlert,
    },
    {
      typeTh: 'มาตรฐานสากล (EICAR AV Test)',
      typeEn: 'Standard AV Signature',
      count: eicarCount,
      color: 'bg-purple-500',
      badge: 'bg-purple-950/60 text-purple-300 border-purple-500/40',
      icon: FileCheck,
    },
  ];

  const totalReports = Math.max(1, reports.length);
  const distinctThreatTypes = virusCategories.filter((c) => c.count > 0 && !c.typeTh.includes('ปลอดภัย')).length;

  return (
    <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-6 backdrop-blur-md relative overflow-hidden shadow-xl flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              {lang === 'th' ? 'จำแนกชนิดไวรัส & ไฟล์ปลอดภัย' : 'Malware Classification & Safety'}
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {lang === 'th'
                ? `ตรวจพบ ${distinctThreatTypes} ชนิดภัยคุกคามในระบบ`
                : `${distinctThreatTypes} distinct malware species detected`}
            </p>
          </div>

          <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/70 border border-cyan-500/30 px-2 py-0.5 rounded-full font-semibold">
            {reports.length} {lang === 'th' ? 'ไฟล์รวม' : 'total'}
          </span>
        </div>

        {/* Categories Breakdown List */}
        <div className="space-y-3 mt-4">
          {virusCategories.map((cat, idx) => {
            const percent = Math.round((cat.count / totalReports) * 100);
            const CatIcon = cat.icon;

            return (
              <div key={idx} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                    <CatIcon className="w-3.5 h-3.5 text-slate-400" />
                    <span>{lang === 'th' ? cat.typeTh : cat.typeEn}</span>
                  </span>
                  <div className="flex items-center gap-1.5 font-mono">
                    <span className="text-white font-bold">{cat.count}</span>
                    <span className="text-[10px] text-slate-500">({percent}%)</span>
                  </div>
                </div>

                <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800/80">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${cat.color}`}
                    style={{ width: `${percent}%` }}
                  ></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="mt-5 pt-4 border-t border-slate-800 text-xs text-slate-400 flex items-center justify-between">
        <span className="text-emerald-400 flex items-center gap-1">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>{safeCount} {lang === 'th' ? 'ไฟล์ปลอดภัย' : 'clean'}</span>
        </span>
        <span className="text-rose-400 flex items-center gap-1">
          <AlertOctagon className="w-3.5 h-3.5" />
          <span>{reports.length - safeCount} {lang === 'th' ? 'ภัยคุกคาม' : 'threats'}</span>
        </span>
      </div>
    </div>
  );
};
