import React from 'react';
import { Shield, ShieldAlert, Radio, Activity, RefreshCw } from 'lucide-react';

interface HeaderProps {
  engineStatus: string;
  hasApiKey: boolean;
  threatCount: number;
  onResetDemo: () => void;
  lang: 'th' | 'en';
  onToggleLang: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  engineStatus,
  hasApiKey,
  threatCount,
  onResetDemo,
  lang,
  onToggleLang,
}) => {
  return (
    <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-40">
      {/* Live threat ticker marquee */}
      <div className="bg-slate-900/90 border-b border-slate-800/50 px-4 py-1 text-xs flex items-center justify-between text-slate-400 overflow-hidden">
        <div className="flex items-center gap-2 shrink-0 pr-4">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-semibold text-emerald-400 uppercase tracking-wider text-[10px]">
            {lang === 'th' ? 'ระบบตรวจจับภัยคุกคามสด' : 'LIVE THREAT FEED'}
          </span>
        </div>

        <div className="flex-1 overflow-hidden whitespace-nowrap text-[11px] text-slate-300">
          <div className="inline-block animate-pulse">
            {lang === 'th'
              ? '⚡ ตรวจสอบไฟล์แบบเรียลไทม์ด้วย AI Heuristics & Gemini 3.8 Flash • วิเคราะห์ Shannon Entropy ละเอียดทุกไบต์ • ตรวจจับ Masquerading, VBA Macro, PowerShell Cradles, และ EICAR มาตรฐานสากล'
              : '⚡ Real-time file inspection via AI Heuristics & Gemini 3.8 Flash • Deep Shannon Entropy & Byte Analysis • Detects Masquerading, VBA Macros, Obfuscated PowerShell & EICAR'}
          </div>
        </div>

        <div className="hidden md:flex items-center gap-3 shrink-0 pl-4 text-[11px]">
          <span className="text-slate-400">
            {lang === 'th' ? 'บล็อกภัยคุกคามวันนี้:' : 'Threats Blocked:'}{' '}
            <strong className="text-rose-400 font-mono">{threatCount + 128}</strong>
          </span>
        </div>
      </div>

      {/* Main navigation bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500/20 via-blue-500/20 to-indigo-500/20 border border-cyan-500/40 shadow-lg shadow-cyan-500/10">
            <Shield className="w-5 h-5 text-cyan-400" />
            <span className="absolute -top-0.5 -right-0.5 flex h-2 w-2">
              <span className="relative inline-flex rounded-full h-2 w-2 bg-cyan-400"></span>
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-extrabold text-lg sm:text-xl tracking-tight text-white flex items-center gap-1.5">
                AegisShield <span className="text-cyan-400">AI</span>
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 font-semibold">
                v2.6 Enterprise
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              {lang === 'th'
                ? 'ระบบสแกนไวรัสและมัลแวร์แบบเรียลไทม์ เจาะลึกทุกซอกทุกมุม'
                : 'Real-time AI File Malware & Deep Heuristic Threat Analyzer'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* AI Engine status pill */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <Radio className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span className="text-slate-400">{lang === 'th' ? 'สถานะ AI:' : 'AI Engine:'}</span>
            <span className="font-medium text-emerald-400 font-mono">
              {hasApiKey ? 'Gemini 3.8 Flash' : 'Hybrid AI Heuristics'}
            </span>
          </div>

          {/* Language toggle */}
          <button
            onClick={onToggleLang}
            aria-label="Toggle language"
            className="px-2.5 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-xs text-slate-300 transition-colors font-semibold"
          >
            {lang === 'th' ? '🇹🇭 TH | EN' : '🌐 EN | TH'}
          </button>

          {/* Reset sample data */}
          <button
            onClick={onResetDemo}
            title={lang === 'th' ? 'คืนค่าประวัติและข้อมูลตัวอย่าง' : 'Reset sample scan history'}
            aria-label="Reset scan history"
            className="p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
